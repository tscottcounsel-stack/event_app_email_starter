// src/pages/OrganizerApplicationsPage.tsx
import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

type ApplicationStatus = "draft" | "submitted" | "approved" | "rejected" | "unknown";

type UploadedDocMeta = {
  doc_id?: string;
  original_name?: string;
  filename?: string;
  size?: number;
  content_type?: string;
  url?: string; // /uploads/...
  uploaded_at?: string;
  uploadedAt?: string; // tolerate camelCase
  [k: string]: any;
};

type ApplicationRow = {
  id: number;
  event_id: number;

  status: string;
  vendor_email?: string | null;
  vendor_id?: string | null;

  booth_id?: string | null;
  app_ref?: string | null;

  notes?: string | null;

  checked?: Record<string, boolean> | null;
  documents?: Record<string, UploadedDocMeta> | null;

  submitted_at?: string | null;
  updated_at?: string | null;
};

type ComplianceRequirement = { id: string; text: string; required?: boolean };
type DocumentRequirement = { id: string; name: string; required?: boolean; dueBy?: string };

type LoadedRequirements = {
  compliance: ComplianceRequirement[];
  documents: DocumentRequirement[];
  source: "api" | "fallback";
  sourceKey?: string;
  raw?: any;
};

const API_BASE = (import.meta as any).env?.VITE_API_BASE || "http://127.0.0.1:8002";

/* ---------------- Auth helpers ---------------- */

function findJwtInLocalStorage(): string {
  try {
    const keys = Object.keys(localStorage);
    for (const k of keys) {
      const v = localStorage.getItem(k);
      if (!v) continue;

      if (v.startsWith("eyJ") && v.split(".").length >= 2) return v;

      try {
        const j = JSON.parse(v);
        const candidates = [
          j?.accessToken,
          j?.token,
          j?.session?.accessToken,
          j?.session?.token,
          j?.auth?.accessToken,
          j?.auth?.token,
          j?.user?.accessToken,
          j?.user?.token,
        ];
        for (const t of candidates) {
          if (typeof t === "string" && t.startsWith("eyJ") && t.split(".").length >= 2) {
            return t;
          }
        }
      } catch {}
    }
  } catch {}
  return "";
}

function authHeaders(extra?: Record<string, string>): Record<string, string> {
  const h: Record<string, string> = {
    Accept: "application/json",
    "Content-Type": "application/json",
    ...(extra || {}),
  };

  const tokenLegacy = localStorage.getItem("accessToken") || "";
  const emailLegacy = localStorage.getItem("userEmail") || "";
  const userIdLegacy = localStorage.getItem("userId") || "";

  const token = tokenLegacy || findJwtInLocalStorage();

  const email =
    emailLegacy ||
    localStorage.getItem("email") ||
    localStorage.getItem("user_email") ||
    "organizer@example.com";

  const userId =
    userIdLegacy ||
    localStorage.getItem("id") ||
    localStorage.getItem("user_id") ||
    "";

  if (token) h.Authorization = `Bearer ${token.startsWith("Bearer ") ? token.slice(7) : token}`;
  if (email) h["x-user-email"] = String(email);
  if (userId) h["x-user-id"] = String(userId);

  return h;
}

/* ---------------- Small helpers ---------------- */

function safeLower(x: any) {
  return String(x ?? "").toLowerCase();
}

function parseStatus(raw: any): ApplicationStatus {
  const s = String(raw ?? "").trim().toLowerCase();
  if (s === "draft") return "draft";
  if (s === "submitted") return "submitted";
  if (s === "approved") return "approved";
  if (s === "rejected") return "rejected";
  return "unknown";
}

function niceStatus(s: ApplicationStatus) {
  switch (s) {
    case "submitted":
      return "Submitted";
    case "approved":
      return "Approved";
    case "rejected":
      return "Rejected";
    case "draft":
      return "Draft";
    default:
      return "Unknown";
  }
}

function statusRank(s: ApplicationStatus) {
  if (s === "submitted") return 1;
  if (s === "draft") return 2;
  if (s === "approved") return 3;
  if (s === "rejected") return 4;
  return 9;
}

function fmtDate(iso?: string | null) {
  if (!iso) return "";
  const t = new Date(iso);
  if (Number.isNaN(t.getTime())) return "";
  return t.toLocaleString();
}

async function fetchJson(url: string, headers?: Record<string, string>) {
  const res = await fetch(url, {
    method: "GET",
    headers: headers || { Accept: "application/json" },
  });
  if (!res.ok) return null;
  try {
    return await res.json();
  } catch {
    return null;
  }
}

/* ---------------- Requirements normalization ---------------- */

function normalizeRequirements(raw: any): LoadedRequirements | null {
  if (!raw) return null;

  const r0: any = raw;
  const r: any = r0?.requirements ?? r0;

  const complianceRaw =
    r?.compliance_items ??
    r?.complianceItems ??
    r?.compliance_requirements ??
    r?.complianceRequirements ??
    r?.requirements ??
    r?.items ??
    [];

  const docsRaw =
    r?.document_requirements ??
    r?.documentRequirements ??
    r?.documents ??
    r?.required_documents ??
    r?.docs ??
    [];

  const compliance: ComplianceRequirement[] = Array.isArray(complianceRaw)
    ? complianceRaw.map((x: any, idx: number) => ({
        id: String(x?.id ?? x?.key ?? x?.code ?? `c_${idx}`),
        text: String(x?.text ?? x?.label ?? x?.name ?? `Requirement ${idx + 1}`),
        required: x?.required !== false,
      }))
    : [];

  const documents: DocumentRequirement[] = Array.isArray(docsRaw)
    ? docsRaw.map((x: any, idx: number) => ({
        id: String(x?.id ?? x?.key ?? x?.code ?? `d_${idx}`),
        name: String(x?.name ?? x?.label ?? x?.title ?? `Document ${idx + 1}`),
        required: x?.required !== false,
        dueBy: x?.due_by ?? x?.dueBy ?? x?.due ?? undefined,
      }))
    : [];

  if (compliance.length === 0 && documents.length === 0) return null;

  return { compliance, documents, source: "api", raw };
}

async function loadRequirements(eventId: number): Promise<LoadedRequirements | null> {
  const url1 = `${API_BASE}/events/${encodeURIComponent(String(eventId))}/requirements`;
  const data1 = await fetchJson(url1);
  const norm1 = normalizeRequirements(data1);
  if (norm1) return { ...norm1, source: "api", sourceKey: url1 };

  const url2 = `${API_BASE}/organizer/events/${encodeURIComponent(String(eventId))}/requirements`;
  const data2 = await fetchJson(url2, authHeaders());
  const norm2 = normalizeRequirements(data2);
  if (norm2) return { ...norm2, source: "api", sourceKey: url2 };

  return null;
}

/* ---------------- Page ---------------- */

export default function OrganizerApplicationsPage() {
  const navigate = useNavigate();
  const params = useParams();
  const eventId = useMemo(() => Number(params.eventId), [params.eventId]);

  const [loading, setLoading] = useState(false);
  const [updatingId, setUpdatingId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [apps, setApps] = useState<ApplicationRow[]>([]);

  const [reqsLoading, setReqsLoading] = useState(false);
  const [reqs, setReqs] = useState<LoadedRequirements | null>(null);

  const [statusFilter, setStatusFilter] = useState<"all" | "submitted" | "approved" | "rejected" | "draft">("all");
  const [query, setQuery] = useState("");
  const [sortBy, setSortBy] = useState<"newest" | "oldest" | "status">("newest");
  const [expanded, setExpanded] = useState<Record<number, boolean>>({});

  const fetchApps = useCallback(async () => {
    if (!eventId || Number.isNaN(eventId)) {
      setError("Invalid event id in route.");
      setApps([]);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await fetch(`${API_BASE}/organizer/events/${eventId}/applications`, {
        method: "GET",
        headers: authHeaders(),
      });

      if (!res.ok) {
        const text = await res.text().catch(() => "");
        throw new Error(`API ${res.status}: ${text || "Failed to load applications"}`);
      }

      const data = (await res.json().catch(() => null)) as any;
      const list = Array.isArray(data?.applications) ? (data.applications as ApplicationRow[]) : [];
      setApps(list);
    } catch (e: any) {
      setError(e?.message ?? "Failed to load applications.");
      setApps([]);
    } finally {
      setLoading(false);
    }
  }, [eventId]);

  const fetchRequirements = useCallback(async () => {
    if (!eventId || Number.isNaN(eventId)) {
      setReqs(null);
      return;
    }
    setReqsLoading(true);
    try {
      const loaded = await loadRequirements(eventId);
      setReqs(loaded);
    } finally {
      setReqsLoading(false);
    }
  }, [eventId]);

  useEffect(() => {
    fetchApps();
    fetchRequirements();
  }, [fetchApps, fetchRequirements]);

  const counts = useMemo(() => {
    const c = { all: 0, draft: 0, submitted: 0, approved: 0, rejected: 0, unknown: 0 };
    c.all = apps.length;
    for (const a of apps) {
      const s = parseStatus(a.status);
      if (s === "draft") c.draft += 1;
      else if (s === "submitted") c.submitted += 1;
      else if (s === "approved") c.approved += 1;
      else if (s === "rejected") c.rejected += 1;
      else c.unknown += 1;
    }
    return c;
  }, [apps]);

  const filtered = useMemo(() => {
    let list = apps;

    if (statusFilter !== "all") {
      list = list.filter((a) => parseStatus(a.status) === statusFilter);
    }

    const q = query.trim().toLowerCase();
    if (q) {
      list = list.filter((a) => {
        const hay = [a.id, a.vendor_email, a.vendor_id, a.booth_id, a.app_ref, a.status]
          .map((x) => safeLower(x))
          .join(" | ");
        return hay.includes(q);
      });
    }

    const sorted = [...list].sort((a, b) => {
      if (sortBy === "status") {
        const ra = statusRank(parseStatus(a.status));
        const rb = statusRank(parseStatus(b.status));
        if (ra !== rb) return ra - rb;
        const aT = new Date(a.submitted_at || a.updated_at || 0).getTime();
        const bT = new Date(b.submitted_at || b.updated_at || 0).getTime();
        return bT - aT;
      }

      const aT = new Date(a.submitted_at || a.updated_at || 0).getTime();
      const bT = new Date(b.submitted_at || b.updated_at || 0).getTime();
      return sortBy === "newest" ? bT - aT : aT - bT;
    });

    return sorted;
  }, [apps, statusFilter, query, sortBy]);

  const busyGlobal = loading || updatingId !== null || reqsLoading;

  const toggleExpanded = useCallback((id: number) => {
    setExpanded((prev) => ({ ...prev, [id]: !prev[id] }));
  }, []);

  const updateStatus = useCallback(
    async (applicationId: number, status: "approved" | "rejected") => {
      setError(null);
      setUpdatingId(applicationId);

      const url = `${API_BASE}/organizer/applications/${applicationId}/status`;
      const body = JSON.stringify({ status });

      async function send(method: "POST" | "PUT") {
        return fetch(url, { method, headers: authHeaders(), body });
      }

      try {
        let res = await send("POST");
        if (res.status === 405) {
          const allow = res.headers.get("Allow") || "";
          if (allow.toUpperCase().includes("PUT")) res = await send("PUT");
        }

        if (!res.ok) {
          const text = await res.text().catch(() => "");
          throw new Error(`API ${res.status}: ${text || "Failed to update application"}`);
        }

        setApps((prev) => prev.map((a) => (a.id === applicationId ? { ...a, status } : a)));
        await fetchApps();
      } catch (e: any) {
        setError(e?.message ?? "Failed to update application.");
      } finally {
        setUpdatingId(null);
      }
    },
    [fetchApps]
  );

  const requiredCompliance = useMemo(() => (reqs?.compliance || []).filter((c) => !!c.required), [reqs]);
  const requiredDocuments = useMemo(() => (reqs?.documents || []).filter((d) => !!d.required), [reqs]);

  function goViewProfile(a: ApplicationRow) {
    const key = (a.vendor_email || a.vendor_id || "").toString().trim();
    if (!key) return;
    navigate(`/organizer/vendors/${encodeURIComponent(key)}`);
  }

  return (
    <div className="min-h-screen bg-white text-slate-900">
      <div className="mx-auto w-full max-w-6xl px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between gap-4">
          <div>
            <div className="text-4xl font-extrabold tracking-tight">Applications</div>
            <div className="mt-1 text-sm text-slate-600">
              Event ID: <span className="font-mono">{String(eventId || "")}</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              className="rounded-full border border-slate-200 px-5 py-2 font-semibold hover:bg-slate-50"
              onClick={() => navigate("/organizer")}
            >
              Back
            </button>
            <button
              className="rounded-full bg-slate-900 px-5 py-2 font-semibold text-white hover:bg-slate-800 disabled:opacity-50"
              onClick={() => {
                fetchApps();
                fetchRequirements();
              }}
              disabled={busyGlobal}
              title={busyGlobal ? "Loading..." : "Refresh"}
            >
              Refresh
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="mt-6 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
            <div className="flex flex-wrap items-center gap-2">
              {(
                [
                  ["all", `All (${counts.all})`],
                  ["submitted", `Submitted (${counts.submitted})`],
                  ["approved", `Approved (${counts.approved})`],
                  ["rejected", `Rejected (${counts.rejected})`],
                  ["draft", `Draft (${counts.draft})`],
                ] as const
              ).map(([key, label]) => (
                <button
                  key={key}
                  className={[
                    "rounded-full border px-4 py-2 text-sm font-semibold",
                    statusFilter === key
                      ? "border-slate-900 bg-slate-900 text-white"
                      : "border-slate-200 bg-white text-slate-800 hover:bg-slate-50",
                  ].join(" ")}
                  onClick={() => setStatusFilter(key)}
                >
                  {label}
                </button>
              ))}
            </div>

            <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-slate-700">Sort</span>
                <select
                  className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm"
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                >
                  <option value="newest">Newest</option>
                  <option value="oldest">Oldest</option>
                  <option value="status">By Status</option>
                </select>
              </div>

              <input
                className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:border-slate-400 sm:w-72"
                placeholder="Search (email, booth, id, status...)"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </div>
          </div>

          {/* Requirements summary */}
          <div className="mt-4 border-t border-slate-100 pt-4">
            <div className="text-sm font-semibold text-slate-800">Requirements Snapshot</div>
            {reqsLoading ? (
              <div className="mt-2 text-sm text-slate-600">Loading requirements…</div>
            ) : !reqs ? (
              <div className="mt-2 text-sm text-slate-600">No requirements found for this event.</div>
            ) : (
              <div className="mt-2 grid gap-4 md:grid-cols-2">
                <div className="rounded-xl border border-slate-200 p-3">
                  <div className="text-xs font-bold uppercase text-slate-500">Required Compliance</div>
                  <div className="mt-2 space-y-1 text-sm text-slate-800">
                    {requiredCompliance.length === 0 ? (
                      <div className="text-slate-600">None</div>
                    ) : (
                      requiredCompliance.slice(0, 5).map((c) => (
                        <div key={c.id} className="flex items-start justify-between gap-2">
                          <span className="truncate">{c.text}</span>
                          <span className="font-mono text-xs text-slate-500">{c.id}</span>
                        </div>
                      ))
                    )}
                    {requiredCompliance.length > 5 ? (
                      <div className="text-xs text-slate-500">+{requiredCompliance.length - 5} more…</div>
                    ) : null}
                  </div>
                </div>

                <div className="rounded-xl border border-slate-200 p-3">
                  <div className="text-xs font-bold uppercase text-slate-500">Required Documents</div>
                  <div className="mt-2 space-y-1 text-sm text-slate-800">
                    {requiredDocuments.length === 0 ? (
                      <div className="text-slate-600">None</div>
                    ) : (
                      requiredDocuments.slice(0, 5).map((d) => (
                        <div key={d.id} className="flex items-start justify-between gap-2">
                          <span className="truncate">
                            {d.name}
                            {d.dueBy ? (
                              <span className="ml-2 text-xs text-slate-500">({String(d.dueBy)})</span>
                            ) : null}
                          </span>
                          <span className="font-mono text-xs text-slate-500">{d.id}</span>
                        </div>
                      ))
                    )}
                    {requiredDocuments.length > 5 ? (
                      <div className="text-xs text-slate-500">+{requiredDocuments.length - 5} more…</div>
                    ) : null}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Errors */}
        {error ? (
          <div className="mt-6 rounded-2xl border border-red-200 bg-red-50 p-5 text-red-800 shadow-sm">
            {error}
          </div>
        ) : null}

        {/* List */}
        <div className="mt-6 space-y-4">
          {loading ? (
            <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
              Loading applications…
            </div>
          ) : filtered.length === 0 ? (
            <div className="rounded-2xl border border-slate-200 bg-white p-6 text-slate-700 shadow-sm">
              No applications match your filters.
            </div>
          ) : (
            filtered.map((a) => {
              const s = parseStatus(a.status);
              const isExpanded = !!expanded[a.id];

              const checkedCount =
                a.checked && typeof a.checked === "object"
                  ? Object.values(a.checked).filter(Boolean).length
                  : 0;

              const docsArr =
                a.documents && typeof a.documents === "object"
                  ? Object.entries(a.documents)
                  : [];

              const hasVendorKey = !!((a.vendor_email || a.vendor_id || "").toString().trim());

              return (
                <div key={a.id} className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                  {/* Row header */}
                  <div className="flex flex-col gap-3 p-5 md:flex-row md:items-center md:justify-between">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <div className="text-lg font-extrabold">
                          App <span className="font-mono">#{a.id}</span>
                        </div>
                        <span
                          className={[
                            "rounded-full px-3 py-1 text-xs font-bold",
                            s === "submitted"
                              ? "bg-amber-100 text-amber-900"
                              : s === "approved"
                              ? "bg-emerald-100 text-emerald-900"
                              : s === "rejected"
                              ? "bg-red-100 text-red-900"
                              : "bg-slate-100 text-slate-800",
                          ].join(" ")}
                        >
                          {niceStatus(s)}
                        </span>
                      </div>

                      <div className="mt-2 flex flex-wrap gap-x-6 gap-y-1 text-sm text-slate-600">
                        <div>
                          Vendor:{" "}
                          <span className="font-mono text-slate-800">
                            {a.vendor_email || a.vendor_id || "—"}
                          </span>
                        </div>
                        <div>
                          Booth: <span className="font-mono text-slate-800">{a.booth_id || "—"}</span>
                        </div>
                        <div>
                          Checked: <span className="font-mono text-slate-800">{checkedCount}</span>
                        </div>
                        <div>
                          Updated: <span className="font-mono text-slate-800">{fmtDate(a.updated_at) || "—"}</span>
                        </div>
                        <div>
                          Submitted: <span className="font-mono text-slate-800">{fmtDate(a.submitted_at) || "—"}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        className="rounded-full border border-slate-200 px-4 py-2 text-sm font-semibold hover:bg-slate-50 disabled:opacity-50"
                        onClick={() => goViewProfile(a)}
                        disabled={!hasVendorKey}
                        title={!hasVendorKey ? "No vendor key on this application yet" : "View vendor profile"}
                      >
                        View Profile
                      </button>

                      <button
                        className="rounded-full border border-slate-200 px-4 py-2 text-sm font-semibold hover:bg-slate-50"
                        onClick={() => toggleExpanded(a.id)}
                      >
                        {isExpanded ? "Hide" : "Review"}
                      </button>

                      <button
                        className="rounded-full bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
                        disabled={busyGlobal || updatingId === a.id}
                        onClick={() => updateStatus(a.id, "approved")}
                        title="Approve this application"
                      >
                        Approve
                      </button>

                      <button
                        className="rounded-full bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-700 disabled:opacity-50"
                        disabled={busyGlobal || updatingId === a.id}
                        onClick={() => updateStatus(a.id, "rejected")}
                        title="Reject this application"
                      >
                        Reject
                      </button>
                    </div>
                  </div>

                  {/* Expanded details */}
                  {isExpanded ? (
                    <div className="border-t border-slate-100 p-5">
                      <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr] items-start">
                        {/* Left: Notes + Checks */}
                        <div className="rounded-2xl border border-slate-200 p-4">
                          <div className="text-sm font-extrabold text-slate-900">Vendor Notes</div>
                          <div className="mt-2 whitespace-pre-wrap text-sm text-slate-700">
                            {a.notes ? a.notes : <span className="text-slate-500">No notes.</span>}
                          </div>

                          <div className="mt-5 text-sm font-extrabold text-slate-900">
                            Checklist (Checked Items)
                          </div>
                          <div className="mt-2 space-y-2">
                            {a.checked && typeof a.checked === "object" ? (
                              Object.entries(a.checked)
                                .filter(([, v]) => !!v)
                                .slice(0, 30)
                                .map(([k]) => (
                                  <div
                                    key={k}
                                    className="flex items-center justify-between rounded-xl border border-slate-200 px-3 py-2"
                                  >
                                    <div className="text-sm text-slate-800">Checked</div>
                                    <div className="font-mono text-xs text-slate-500">{k}</div>
                                  </div>
                                ))
                            ) : (
                              <div className="text-sm text-slate-500">No checklist data.</div>
                            )}
                            {a.checked &&
                            typeof a.checked === "object" &&
                            Object.entries(a.checked).filter(([, v]) => !!v).length > 30 ? (
                              <div className="text-xs text-slate-500">Showing first 30 checked…</div>
                            ) : null}
                          </div>
                        </div>

                        {/* Right: Uploaded Docs */}
                        <div className="rounded-2xl border border-slate-200 p-4">
                          <div className="text-sm font-extrabold text-slate-900">Uploaded Documents</div>
                          <div className="mt-2 text-xs text-slate-500">
                            (This shows whatever metadata the vendor submitted. Real file download links can come later.)
                          </div>

                          <div className="mt-4 space-y-3">
                            {docsArr.length === 0 ? (
                              <div className="text-sm text-slate-500">No documents attached.</div>
                            ) : (
                              docsArr.map(([docKey, meta]) => {
                                const name =
                                  meta?.original_name ||
                                  meta?.filename ||
                                  meta?.name ||
                                  meta?.file ||
                                  "Unnamed file";
                                const when = meta?.uploaded_at || meta?.uploadedAt || "";
                                return (
                                  <div key={docKey} className="rounded-xl border border-slate-200 p-3">
                                    <div className="text-sm font-semibold text-slate-900">{name}</div>
                                    <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-500">
                                      <div>
                                        Doc ID: <span className="font-mono">{meta?.doc_id || docKey}</span>
                                      </div>
                                      {meta?.size ? (
                                        <div>
                                          Size: <span className="font-mono">{String(meta.size)}</span>
                                        </div>
                                      ) : null}
                                      {meta?.content_type ? (
                                        <div>
                                          Type: <span className="font-mono">{String(meta.content_type)}</span>
                                        </div>
                                      ) : null}
                                      {when ? (
                                        <div>
                                          Uploaded: <span className="font-mono">{fmtDate(when)}</span>
                                        </div>
                                      ) : null}
                                    </div>

                                    {meta?.url ? (
                                      <div className="mt-2 text-xs text-slate-600">
                                        URL: <span className="font-mono">{String(meta.url)}</span>
                                      </div>
                                    ) : null}
                                  </div>
                                );
                              })
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : null}
                </div>
              );
            })
          )}
        </div>

        <div className="mt-10 text-center text-xs text-slate-400">OrganizerApplicationsPage</div>
      </div>
    </div>
  );
}
