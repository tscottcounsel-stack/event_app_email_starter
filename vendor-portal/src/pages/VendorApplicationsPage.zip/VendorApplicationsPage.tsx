// src/pages/VendorApplicationsPage.tsx
import React, { useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";

type VendorProgress = {
  eventId: string;
  appId: string;
  boothId?: string;
  checked: Record<string, boolean>;
  notes?: string;
  updatedAt: string;
  status?: "draft" | "submitted";
  submittedAt?: string;
};

const LS_VENDOR_PROGRESS = "vendor_requirements_progress_v1";

function safeJsonParse<T = any>(value: string | null): T | null {
  if (!value) return null;
  try {
    return JSON.parse(value) as T;
  } catch {
    return null;
  }
}

function formatDate(iso: string) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleString();
}

function calcCompletion(item: VendorProgress) {
  const keys = Object.keys(item.checked || {});
  if (keys.length === 0) return { done: 0, total: 0, pct: 100 };
  const done = keys.filter((k) => item.checked[k]).length;
  const total = keys.length;
  const pct = total === 0 ? 100 : Math.round((done / total) * 100);
  return { done, total, pct };
}

export default function VendorApplicationsPage() {
  const nav = useNavigate();

  const items = useMemo(() => {
    const raw = safeJsonParse<VendorProgress[]>(localStorage.getItem(LS_VENDOR_PROGRESS));
    const list = Array.isArray(raw) ? raw : [];

    // newest first
    return list
      .slice()
      .sort((a, b) => {
        const ta = new Date(a.updatedAt || 0).getTime();
        const tb = new Date(b.updatedAt || 0).getTime();
        return tb - ta;
      });
  }, []);

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="mx-auto max-w-6xl px-6 py-10">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-4xl font-black tracking-tight text-slate-900">Applications</h1>
            <p className="mt-2 text-sm font-semibold text-slate-600">
              Drafts and submissions you’ve saved.
            </p>
          </div>

          <button
            onClick={() => nav("/vendor/events")}
            className="rounded-full bg-slate-900 px-4 py-2 text-sm font-extrabold text-white hover:bg-slate-800"
            type="button"
          >
            Browse Events
          </button>
        </div>

        {items.length === 0 ? (
          <div className="mt-10 rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
            <div className="text-xl font-black text-slate-900">No applications yet</div>
            <div className="mt-2 text-sm font-semibold text-slate-600">
              When you save a draft or submit an application, it will show up here.
            </div>

            <div className="mt-6 flex gap-3">
              <button
                onClick={() => nav("/vendor/events")}
                className="rounded-full bg-slate-900 px-4 py-2 text-sm font-extrabold text-white hover:bg-slate-800"
                type="button"
              >
                Find Events
              </button>
            </div>
          </div>
        ) : (
          <div className="mt-10 grid gap-4">
            {items.map((it) => {
              const { done, total, pct } = calcCompletion(it);
              const status: "draft" | "submitted" = it.status || "draft";

              return (
                <div
                  key={it.appId}
                  className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"
                >
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="min-w-[240px]">
                      <div className="text-lg font-black text-slate-900">
                        Event #{it.eventId}
                        {it.boothId ? (
                          <span className="ml-2 text-sm font-extrabold text-slate-500">
                            • Booth {it.boothId}
                          </span>
                        ) : null}
                      </div>

                      <div className="mt-1 text-xs font-semibold text-slate-500">
                        Last updated: {formatDate(it.updatedAt)}
                        {status === "submitted" && it.submittedAt ? (
                          <span className="ml-2">• Submitted: {formatDate(it.submittedAt)}</span>
                        ) : null}
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <span
                        className={
                          "rounded-full px-3 py-1 text-xs font-extrabold " +
                          (status === "submitted"
                            ? "bg-emerald-50 text-emerald-700"
                            : "bg-slate-100 text-slate-700")
                        }
                      >
                        {status === "submitted" ? "Submitted" : "Draft"}
                      </span>

                      <div className="text-sm font-extrabold text-slate-700">
                        {pct}% <span className="font-semibold text-slate-500">({done}/{total})</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4">
                    <div className="h-2 w-full overflow-hidden rounded-full bg-slate-100">
                      <div
                        className="h-2 rounded-full bg-violet-500"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>

                  <div className="mt-5 flex flex-wrap gap-3">
                    <Link
                      to={`/vendor/events/${it.eventId}/apply?appId=${encodeURIComponent(it.appId)}`}
                      className="rounded-full bg-violet-600 px-4 py-2 text-sm font-extrabold text-white hover:bg-violet-700"
                    >
                      {status === "submitted" ? "View Application" : "Continue"}
                    </Link>

                    <Link
                      to={`/vendor/events/${it.eventId}`}
                      className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-extrabold text-slate-900 hover:bg-slate-50"
                    >
                      View Event
                    </Link>

                    <button
                      onClick={() => {
                        const raw = safeJsonParse<VendorProgress[]>(
                          localStorage.getItem(LS_VENDOR_PROGRESS)
                        );
                        const list = Array.isArray(raw) ? raw : [];
                        const next = list.filter((x) => x.appId !== it.appId);
                        localStorage.setItem(LS_VENDOR_PROGRESS, JSON.stringify(next));
                        window.location.reload();
                      }}
                      className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-extrabold text-slate-600 hover:bg-slate-50"
                      type="button"
                    >
                      Remove
                    </button>
                  </div>

                  {it.notes ? (
                    <div className="mt-4 rounded-xl bg-slate-50 p-4 text-sm font-semibold text-slate-700">
                      <div className="text-xs font-extrabold uppercase tracking-wide text-slate-500">
                        Notes
                      </div>
                      <div className="mt-1 whitespace-pre-wrap">{it.notes}</div>
                    </div>
                  ) : null}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
