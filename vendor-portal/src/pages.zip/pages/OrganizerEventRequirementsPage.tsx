import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";

/* ---------------- Types ---------------- */

type BoothCategory = {
  id: string;
  name: string;
  baseSize: string; // e.g. "10x10"
  basePrice: number; // dollars
};

type VendorRestriction = {
  id: string;
  text: string;
};

type ComplianceRequirement = {
  id: string;
  text: string;
  required: boolean;
};

type DocumentRequirement = {
  id: string;
  name: string;
  required: boolean;
  dueBy?: string; // freeform
};

type RefundPolicy =
  | "No Refunds"
  | "Full Refund"
  | "Partial Refund"
  | "Event Credits Only";

type PaymentSettings = {
  requireDeposit: boolean;
  depositPercent: number; // 0-100
  lateFee: number; // dollars
  refundPolicy: RefundPolicy;
  paymentNotes?: string;
};

type RequirementsModel = {
  version: string;
  eventId: number;

  boothCategories: BoothCategory[];
  customRestrictions: VendorRestriction[];
  complianceItems: ComplianceRequirement[];
  documentRequirements: DocumentRequirement[];
  paymentSettings: PaymentSettings;

  updatedAt?: string;
};

type EventConfigTemplate = {
  id: string;
  name: string;
  description: string;
  createdAt: string;

  boothCategories: BoothCategory[];
  customRestrictions: VendorRestriction[];
  complianceItems: ComplianceRequirement[];
  documentRequirements: DocumentRequirement[];
  paymentSettings: PaymentSettings;
};

/* ---------------- Config ---------------- */

const API_BASE = (import.meta as any).env?.VITE_API_BASE || "http://127.0.0.1:8002";

const LS_EVENT_REQ_PREFIX = "organizer:event";
const LS_TEMPLATES_KEY = "event-config-templates";

const ENDPOINTS = {
  getRequirements: (eventId: string) => [
    `/events/${eventId}/requirements`,
    `/requirements/${eventId}`,
    `/organizer/events/${eventId}/requirements`,
  ],
  saveRequirements: (eventId: string) => [
    { method: "PUT" as const, path: `/events/${eventId}/requirements` },
    { method: "POST" as const, path: `/events/${eventId}/requirements` },
    { method: "PUT" as const, path: `/requirements/${eventId}` },
    { method: "POST" as const, path: `/requirements/${eventId}` },
  ],
};

/* ---------------- Helpers ---------------- */

function uid(prefix = "id") {
  return `${prefix}_${Math.random().toString(16).slice(2)}_${Date.now()}`;
}

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

async function fetchJson(path: string, opts: { accessToken?: string } = {}) {
  const headers: Record<string, string> = { Accept: "application/json" };
  if (opts.accessToken) headers.Authorization = `Bearer ${opts.accessToken}`;

  const res = await fetch(`${API_BASE}${path}`, { headers });
  const ct = res.headers.get("content-type") || "";
  const isJson = ct.includes("application/json");
  const data = isJson ? await res.json().catch(() => null) : await res.text().catch(() => null);
  return { ok: res.ok, status: res.status, data };
}

async function saveJson(
  method: "POST" | "PUT",
  path: string,
  body: any,
  opts: { accessToken?: string } = {}
) {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    Accept: "application/json",
  };
  if (opts.accessToken) headers.Authorization = `Bearer ${opts.accessToken}`;

  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers,
    body: JSON.stringify(body),
  });

  const ct = res.headers.get("content-type") || "";
  const isJson = ct.includes("application/json");
  const data = isJson ? await res.json().catch(() => null) : await res.text().catch(() => null);

  return { ok: res.ok, status: res.status, data };
}

function readTemplates(): EventConfigTemplate[] {
  try {
    const raw = localStorage.getItem(LS_TEMPLATES_KEY);
    const arr = JSON.parse(raw || "[]");
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

function writeTemplates(list: EventConfigTemplate[]) {
  localStorage.setItem(LS_TEMPLATES_KEY, JSON.stringify(list));
}

function toRequirementsModel(eventId: number, src: Partial<RequirementsModel> | null | undefined): RequirementsModel {
  const base: RequirementsModel = {
    version: "event_requirements_v1_2",
    eventId,
    boothCategories: [],
    customRestrictions: [],
    complianceItems: [],
    documentRequirements: [],
    paymentSettings: {
      requireDeposit: true,
      depositPercent: 50,
      refundPolicy: "No Refunds",
      lateFee: 0,
      paymentNotes: "",
    },
    updatedAt: new Date().toISOString(),
  };

  if (!src) return base;

  return {
    ...base,
    ...src,
    eventId,
    boothCategories: Array.isArray(src.boothCategories) ? src.boothCategories : base.boothCategories,
    customRestrictions: Array.isArray(src.customRestrictions) ? src.customRestrictions : base.customRestrictions,
    complianceItems: Array.isArray(src.complianceItems) ? src.complianceItems : base.complianceItems,
    documentRequirements: Array.isArray(src.documentRequirements)
      ? src.documentRequirements
      : base.documentRequirements,
    paymentSettings: {
      ...base.paymentSettings,
      ...(src.paymentSettings || {}),
    },
    updatedAt: src.updatedAt || new Date().toISOString(),
  };
}

/* ---------------- Pre-built Templates (from README) ---------------- */

const PREBUILT: { key: string; title: string; emoji: string; description: string; data: Omit<EventConfigTemplate, "id" | "createdAt"> }[] =
  [
    {
      key: "tech",
      title: "Tech Conference",
      emoji: "🖥️",
      description: "Technology exhibitions and trade shows",
      data: {
        name: "Tech Conference",
        description: "Pre-built tech conference template",
        boothCategories: [
          { id: uid("cat"), name: "Standard Booth", baseSize: "10x10", basePrice: 1500 },
          { id: uid("cat"), name: "Premium Booth", baseSize: "10x20", basePrice: 3000 },
          { id: uid("cat"), name: "Island Booth", baseSize: "20x20", basePrice: 6000 },
        ],
        customRestrictions: [
          { id: uid("r"), text: "No unauthorized solicitation" },
          { id: uid("r"), text: "No unauthorized recordings" },
          { id: uid("r"), text: "No event branding on merchandise" },
        ],
        complianceItems: [
          { id: uid("c"), text: "Product demos tested 24hrs prior", required: true },
          { id: uid("c"), text: "GDPR-compliant lead capture", required: true },
          { id: uid("c"), text: "Setup by 7am", required: true },
          { id: uid("c"), text: "WiFi coordination", required: false },
        ],
        documentRequirements: [
          { id: uid("d"), name: "Certificate of Insurance (COI)", required: true, dueBy: "30 days before" },
          { id: uid("d"), name: "W-9 Tax Form", required: true, dueBy: "" },
          { id: uid("d"), name: "Product Spec Sheet", required: false, dueBy: "" },
        ],
        paymentSettings: {
          requireDeposit: true,
          depositPercent: 50,
          refundPolicy: "Partial Refund",
          lateFee: 100,
          paymentNotes: "50% deposit required. Partial refund policy. $100 late fee.",
        },
      },
    },
    {
      key: "art",
      title: "Art Fair",
      emoji: "🎨",
      description: "Art shows, craft fairs, maker markets",
      data: {
        name: "Art Fair",
        description: "Pre-built art fair template",
        boothCategories: [
          { id: uid("cat"), name: "Gallery Space", baseSize: "10x10", basePrice: 200 },
          { id: uid("cat"), name: "Outdoor Tent", baseSize: "10x15", basePrice: 300 },
          { id: uid("cat"), name: "Pop-up Display", baseSize: "8x8", basePrice: 150 },
        ],
        customRestrictions: [
          { id: uid("r"), text: "Original artwork only" },
          { id: uid("r"), text: "Artist must be present" },
          { id: uid("r"), text: "Family-friendly content" },
        ],
        complianceItems: [
          { id: uid("c"), text: "Self-standing display", required: true },
          { id: uid("c"), text: "Visible price tags", required: true },
          { id: uid("c"), text: "Trash removal", required: true },
          { id: uid("c"), text: "Business signage", required: false },
        ],
        documentRequirements: [
          { id: uid("d"), name: "Artist Bio & Headshot", required: true, dueBy: "14 days before" },
          { id: uid("d"), name: "Portfolio Samples", required: true, dueBy: "" },
          { id: uid("d"), name: "Proof of Original Work", required: true, dueBy: "" },
        ],
        paymentSettings: {
          requireDeposit: false,
          depositPercent: 100,
          refundPolicy: "No Refunds",
          lateFee: 0,
          paymentNotes: "100% payment upfront. No refunds. No late fees.",
        },
      },
    },
    {
      key: "food",
      title: "Food Festival",
      emoji: "🍔",
      description: "Health & safety heavy food events",
      data: {
        name: "Food Festival",
        description: "Pre-built food festival template",
        boothCategories: [
          { id: uid("cat"), name: "Food Trailer", baseSize: "15x30", basePrice: 1200 },
          { id: uid("cat"), name: "Quick Service", baseSize: "10x10", basePrice: 600 },
          { id: uid("cat"), name: "Full Kitchen", baseSize: "10x20", basePrice: 800 },
        ],
        customRestrictions: [
          { id: uid("r"), text: "No outside food/beverage" },
          { id: uid("r"), text: "No alcohol without license" },
        ],
        complianceItems: [
          { id: uid("c"), text: "Ground cover required", required: true },
          { id: uid("c"), text: "Grease disposal", required: true },
          { id: uid("c"), text: "Fire extinguisher", required: true },
          { id: uid("c"), text: "Trash bagging", required: true },
        ],
        documentRequirements: [
          { id: uid("d"), name: "General Liability Insurance", required: true, dueBy: "14 days before" },
          { id: uid("d"), name: "Health Permit", required: true, dueBy: "7 days before" },
          { id: uid("d"), name: "Business License", required: true, dueBy: "" },
          { id: uid("d"), name: "Menu Attachments", required: false, dueBy: "" },
        ],
        paymentSettings: {
          requireDeposit: true,
          depositPercent: 50,
          refundPolicy: "Partial Refund",
          lateFee: 50,
          paymentNotes: "50% deposit required. Partial refund policy. $50 late fee.",
        },
      },
    },
    {
      key: "music",
      title: "Music Festival",
      emoji: "🎵",
      description: "Merchandise + food vendors at festivals",
      data: {
        name: "Music Festival",
        description: "Pre-built music festival template",
        boothCategories: [
          { id: uid("cat"), name: "Merchandise Booth", baseSize: "10x10", basePrice: 400 },
          { id: uid("cat"), name: "Food Vendor", baseSize: "10x15", basePrice: 800 },
          { id: uid("cat"), name: "Sponsor Booth", baseSize: "10x20", basePrice: 2000 },
        ],
        customRestrictions: [
          { id: uid("r"), text: "No unauthorized performances" },
          { id: uid("r"), text: "No alcohol sales" },
          { id: uid("r"), text: "Volume restrictions" },
        ],
        complianceItems: [
          { id: uid("c"), text: "Setup by 9am", required: true },
          { id: uid("c"), text: "No early breakdown", required: true },
          { id: uid("c"), text: "Trash disposal", required: true },
          { id: uid("c"), text: "Own power source", required: false },
        ],
        documentRequirements: [
          { id: uid("d"), name: "General Liability Insurance", required: true, dueBy: "14 days before" },
          { id: uid("d"), name: "Business License", required: true, dueBy: "" },
          { id: uid("d"), name: "Sales Tax Certificate", required: false, dueBy: "" },
        ],
        paymentSettings: {
          requireDeposit: true,
          depositPercent: 50,
          refundPolicy: "Event Credits Only",
          lateFee: 50,
          paymentNotes: "50% deposit required. Event credits only refund. $50 late fee.",
        },
      },
    },
  ];

/* ---------------- Component ---------------- */

export default function OrganizerEventRequirementsPage() {
  const navigate = useNavigate();
  const { eventId } = useParams();
  const { accessToken } = useAuth();

  const eid = useMemo(() => {
    const n = Number(eventId);
    return Number.isFinite(n) ? n : null;
  }, [eventId]);

  const storageKey = useMemo(() => {
    if (!eventId) return `${LS_EVENT_REQ_PREFIX}:unknown:requirements`;
    return `${LS_EVENT_REQ_PREFIX}:${eventId}:requirements`;
  }, [eventId]);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [model, setModel] = useState<RequirementsModel | null>(null);

  // templates UI
  const [templates, setTemplates] = useState<EventConfigTemplate[]>([]);
  const [saveModalOpen, setSaveModalOpen] = useState(false);
  const [tplName, setTplName] = useState("");
  const [tplDesc, setTplDesc] = useState("");

  useEffect(() => {
    setTemplates(readTemplates());
  }, []);

  useEffect(() => {
    let alive = true;

    async function load() {
      setLoading(true);
      setError(null);
      setToast(null);

      if (!eventId || !eid) {
        setLoading(false);
        setError("Missing or invalid event id.");
        return;
      }

      // 1) Try API
      for (const path of ENDPOINTS.getRequirements(eventId)) {
        const r = await fetchJson(path, { accessToken });
        if (r.ok && r.data) {
          if (!alive) return;
          const raw = (r.data.requirements ?? r.data) as Partial<RequirementsModel>;
          const hydrated = toRequirementsModel(eid, raw);

          // ensure ids exist
          hydrated.boothCategories = (hydrated.boothCategories || []).map((c) => ({ id: c.id || uid("cat"), ...c }));
          hydrated.customRestrictions = (hydrated.customRestrictions || []).map((x) => ({ id: x.id || uid("r"), ...x }));
          hydrated.complianceItems = (hydrated.complianceItems || []).map((x) => ({ id: x.id || uid("c"), ...x }));
          hydrated.documentRequirements = (hydrated.documentRequirements || []).map((x) => ({ id: x.id || uid("d"), ...x }));

          setModel(hydrated);
          setLoading(false);
          return;
        }
      }

      // 2) Try local cached requirements
      const cached = localStorage.getItem(storageKey);
      if (cached) {
        try {
          const parsed = JSON.parse(cached);
          if (!alive) return;
          setModel(toRequirementsModel(eid, parsed));
          setLoading(false);
          return;
        } catch {
          // ignore
        }
      }

      // 3) Default to Tech Conference (not blank)
      const tech = PREBUILT.find((p) => p.key === "tech")!;
      const seeded: RequirementsModel = toRequirementsModel(eid, {
        version: "event_requirements_v1_2",
        eventId: eid,
        ...tech.data,
        paymentSettings: tech.data.paymentSettings,
      } as any);

      setModel(seeded);
      setLoading(false);
    }

    load();
    return () => {
      alive = false;
    };
  }, [eventId, eid, storageKey, accessToken]);

  function bump(m: RequirementsModel) {
    return { ...m, updatedAt: new Date().toISOString() };
  }

  function applyTemplateData(data: Omit<EventConfigTemplate, "id" | "createdAt" | "name" | "description">) {
    if (!model) return;
    const next: RequirementsModel = bump({
      ...model,
      boothCategories: data.boothCategories.map((c) => ({ ...c, id: uid("cat") })),
      customRestrictions: data.customRestrictions.map((r) => ({ ...r, id: uid("r") })),
      complianceItems: data.complianceItems.map((c) => ({ ...c, id: uid("c") })),
      documentRequirements: data.documentRequirements.map((d) => ({ ...d, id: uid("d") })),
      paymentSettings: { ...data.paymentSettings },
    });
    setModel(next);
    setToast("Template loaded.");
    setError(null);
  }

  function loadSavedTemplate(tpl: EventConfigTemplate) {
    applyTemplateData({
      boothCategories: tpl.boothCategories,
      customRestrictions: tpl.customRestrictions,
      complianceItems: tpl.complianceItems,
      documentRequirements: tpl.documentRequirements,
      paymentSettings: tpl.paymentSettings,
    });
  }

  function deleteTemplate(id: string) {
    const next = templates.filter((t) => t.id !== id);
    setTemplates(next);
    writeTemplates(next);
    setToast("Template deleted.");
  }

  function openSaveTemplateModal() {
    setTplName("");
    setTplDesc("");
    setSaveModalOpen(true);
  }

  function saveAsTemplate() {
    if (!model) return;

    const name = tplName.trim();
    if (!name) {
      setToast("Template name is required.");
      return;
    }

    const tpl: EventConfigTemplate = {
      id: uid("tpl"),
      name,
      description: tplDesc.trim(),
      createdAt: new Date().toISOString(),
      boothCategories: model.boothCategories,
      customRestrictions: model.customRestrictions,
      complianceItems: model.complianceItems,
      documentRequirements: model.documentRequirements,
      paymentSettings: model.paymentSettings,
    };

    const next = [tpl, ...templates];
    setTemplates(next);
    writeTemplates(next);
    setSaveModalOpen(false);
    setToast("Template saved.");
  }

  function updateCategory(id: string, patch: Partial<BoothCategory>) {
    if (!model) return;
    setModel(
      bump({
        ...model,
        boothCategories: model.boothCategories.map((c) => (c.id === id ? { ...c, ...patch } : c)),
      })
    );
  }

  function updateRestriction(id: string, patch: Partial<VendorRestriction>) {
    if (!model) return;
    setModel(
      bump({
        ...model,
        customRestrictions: model.customRestrictions.map((r) => (r.id === id ? { ...r, ...patch } : r)),
      })
    );
  }

  function updateCompliance(id: string, patch: Partial<ComplianceRequirement>) {
    if (!model) return;
    setModel(
      bump({
        ...model,
        complianceItems: model.complianceItems.map((c) => (c.id === id ? { ...c, ...patch } : c)),
      })
    );
  }

  function updateDocument(id: string, patch: Partial<DocumentRequirement>) {
    if (!model) return;
    setModel(
      bump({
        ...model,
        documentRequirements: model.documentRequirements.map((d) => (d.id === id ? { ...d, ...patch } : d)),
      })
    );
  }

  function removeById(list: "boothCategories" | "customRestrictions" | "complianceItems" | "documentRequirements", id: string) {
    if (!model) return;
    setModel(
      bump({
        ...model,
        [list]: (model as any)[list].filter((x: any) => x.id !== id),
      } as any)
    );
  }

  function addCategory() {
    if (!model) return;
    setModel(
      bump({
        ...model,
        boothCategories: [...model.boothCategories, { id: uid("cat"), name: "New Category", baseSize: "10x10", basePrice: 0 }],
      })
    );
  }

  function addRestriction() {
    if (!model) return;
    setModel(
      bump({
        ...model,
        customRestrictions: [...model.customRestrictions, { id: uid("r"), text: "New restriction" }],
      })
    );
  }

  function addCompliance() {
    if (!model) return;
    setModel(
      bump({
        ...model,
        complianceItems: [...model.complianceItems, { id: uid("c"), text: "New compliance item", required: true }],
      })
    );
  }

  function addDocument() {
    if (!model) return;
    setModel(
      bump({
        ...model,
        documentRequirements: [...model.documentRequirements, { id: uid("d"), name: "New document", required: true, dueBy: "" }],
      })
    );
  }

  async function onSave() {
    if (!model || !eventId) return false;
    setSaving(true);
    setError(null);
    setToast(null);

    // always cache locally
    try {
      localStorage.setItem(storageKey, JSON.stringify(model));
    } catch {
      // ignore
    }

    // attempt API save
    let lastErr: string | null = null;

    for (const attempt of ENDPOINTS.saveRequirements(eventId)) {
      const res = await saveJson(attempt.method, attempt.path, model, { accessToken });
      if (res.ok) {
        setSaving(false);
        setToast("Saved!");
        return true;
      }
      lastErr =
        (typeof res.data === "string" ? res.data : null) ||
        res.data?.detail ||
        res.data?.message ||
        `Save failed (${res.status})`;
    }

    setSaving(false);
    setToast("Saved locally (API save failed).");
    if (lastErr) setError(lastErr);
    return false;
  }

  async function onSaveAndContinue() {
    await onSave();
    if (eventId) navigate(`/organizer/events/${eventId}/layout`);
  }

  if (loading) {
    return (
      <div className="mx-auto max-w-6xl px-6 py-10">
        <div className="text-xl font-black text-slate-900">Loading requirements…</div>
      </div>
    );
  }

  if (!model || !eid) {
    return (
      <div className="mx-auto max-w-6xl px-6 py-10">
        <div className="text-xl font-black text-slate-900">Requirements</div>
        <div className="mt-3 rounded-2xl border border-red-200 bg-red-50 p-4 text-sm font-semibold text-red-700">
          {error || "Unable to load requirements."}
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-6 py-10">
      <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
        <div>
          <h1 className="text-3xl font-black text-slate-900">Event {model.eventId} Requirements Builder</h1>
          <div className="mt-2 text-sm font-semibold text-slate-600">
            Load a template, customize requirements, save, then continue to Map Editor.
          </div>

          <div className="mt-3 text-xs font-semibold text-slate-500">
            Debug keys:
            <div>organizer:event:{model.eventId}:requirements</div>
            <div>{model.version}</div>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={onSave}
            disabled={saving}
            className="rounded-2xl bg-indigo-600 px-5 py-3 text-sm font-black text-white disabled:opacity-60"
          >
            {saving ? "Saving…" : "Save Requirements"}
          </button>

          <button
            type="button"
            onClick={() => navigate(`/organizer/events/${model.eventId}/review`)}
            className="rounded-2xl border border-slate-200 bg-white px-5 py-3 text-sm font-black text-slate-900 hover:bg-slate-50"
          >
            Review
          </button>

          <button
            type="button"
            onClick={onSaveAndContinue}
            disabled={saving}
            className="rounded-2xl border border-slate-200 bg-white px-5 py-3 text-sm font-black text-slate-900 hover:bg-slate-50 disabled:opacity-60"
          >
            Save & Continue → Map Editor
          </button>
        </div>
      </div>

      {toast ? (
        <div className="mt-4 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-semibold text-emerald-800">
          {toast}
        </div>
      ) : null}

      {error ? (
        <div className="mt-4 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm font-semibold text-amber-800">
          {error}
        </div>
      ) : null}

      {/* ---------------- Templates Section ---------------- */}
      <section className="mt-8 rounded-[26px] border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
          <div>
            <div className="text-lg font-black text-slate-900">Templates</div>
            <div className="mt-1 text-sm font-semibold text-slate-600">
              Load a pre-built template or manage your saved templates. Loading overwrites current configuration.
            </div>
          </div>

          <button
            type="button"
            onClick={openSaveTemplateModal}
            className="rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-black text-slate-900 hover:bg-slate-50"
          >
            Save as Template
          </button>
        </div>

        <div className="mt-5 grid gap-4 md:grid-cols-2">
          {PREBUILT.map((t) => (
            <button
              key={t.key}
              type="button"
              onClick={() =>
                applyTemplateData({
                  boothCategories: t.data.boothCategories,
                  customRestrictions: t.data.customRestrictions,
                  complianceItems: t.data.complianceItems,
                  documentRequirements: t.data.documentRequirements,
                  paymentSettings: t.data.paymentSettings,
                })
              }
              className="text-left rounded-3xl border border-slate-200 bg-slate-50 p-5 hover:bg-slate-100 transition"
            >
              <div className="flex items-start gap-4">
                <div className="grid h-12 w-12 place-items-center rounded-2xl bg-white shadow-sm">
                  <span className="text-2xl">{t.emoji}</span>
                </div>
                <div className="flex-1">
                  <div className="text-base font-black text-slate-900">{t.title}</div>
                  <div className="mt-1 text-sm font-semibold text-slate-600">{t.description}</div>
                  <div className="mt-3 text-xs font-bold text-slate-500">
                    Booths: {t.data.boothCategories.length} • Restrictions: {t.data.customRestrictions.length} • Compliance:{" "}
                    {t.data.complianceItems.length} • Docs: {t.data.documentRequirements.length}
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>

        <div className="mt-8">
          <div className="flex items-center justify-between">
            <div className="text-sm font-black text-slate-900">
              Your Saved Templates <span className="ml-2 rounded-full bg-slate-100 px-2 py-1 text-xs">{templates.length}</span>
            </div>
          </div>

          {templates.length === 0 ? (
            <div className="mt-3 text-sm font-semibold text-slate-600">
              No saved templates yet. Configure requirements below, then click <span className="font-black">Save as Template</span>.
            </div>
          ) : (
            <div className="mt-4 grid gap-3">
              {templates.map((tpl) => (
                <div key={tpl.id} className="flex flex-col gap-2 rounded-2xl border border-slate-200 bg-white p-4 md:flex-row md:items-center md:justify-between">
                  <div>
                    <div className="text-sm font-black text-slate-900">{tpl.name}</div>
                    {tpl.description ? (
                      <div className="mt-1 text-xs font-semibold text-slate-600">{tpl.description}</div>
                    ) : null}
                    <div className="mt-2 text-xs font-bold text-slate-500">
                      Booths: {tpl.boothCategories.length} • Restrictions: {tpl.customRestrictions.length} • Compliance:{" "}
                      {tpl.complianceItems.length} • Docs: {tpl.documentRequirements.length}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => loadSavedTemplate(tpl)}
                      className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-black text-slate-900 hover:bg-slate-50"
                    >
                      ⬆ Load
                    </button>
                    <button
                      type="button"
                      onClick={() => deleteTemplate(tpl.id)}
                      className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-black text-slate-700 hover:bg-slate-50"
                    >
                      🗑 Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* ---------------- Booth Categories ---------------- */}
      <Section
        title="Booth Categories"
        subtitle="Define booth options and pricing that vendors will select during application."
        onAdd={addCategory}
        addLabel="+ Add Category"
      >
        <div className="grid gap-3">
          {model.boothCategories.map((c) => (
            <div key={c.id} className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
              <div className="flex flex-col gap-3 md:flex-row md:items-center">
                <input
                  value={c.name}
                  onChange={(e) => updateCategory(c.id, { name: e.target.value })}
                  className={inputCls}
                  placeholder="Category name"
                />
                <input
                  value={c.baseSize}
                  onChange={(e) => updateCategory(c.id, { baseSize: e.target.value })}
                  className={inputCls}
                  placeholder="Base size (e.g., 10x10)"
                />
                <input
                  value={String(c.basePrice ?? 0)}
                  onChange={(e) => updateCategory(c.id, { basePrice: clamp(Number(e.target.value || 0), 0, 999999) })}
                  className={inputCls}
                  inputMode="numeric"
                  placeholder="Price"
                />
                <button
                  type="button"
                  onClick={() => removeById("boothCategories", c.id)}
                  className={smallBtn}
                >
                  Remove
                </button>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* ---------------- Restrictions ---------------- */}
      <Section
        title="Restrictions"
        subtitle="These are rules vendors must follow (e.g., solicitation, recordings, alcohol restrictions)."
        onAdd={addRestriction}
        addLabel="+ Add Restriction"
      >
        <div className="grid gap-3">
          {model.customRestrictions.map((r) => (
            <div key={r.id} className="flex flex-col gap-2 rounded-2xl border border-slate-200 bg-slate-50 p-4 md:flex-row md:items-center">
              <input
                value={r.text}
                onChange={(e) => updateRestriction(r.id, { text: e.target.value })}
                className={inputCls}
                placeholder="Restriction text"
              />
              <button type="button" onClick={() => removeById("customRestrictions", r.id)} className={smallBtn}>
                Remove
              </button>
            </div>
          ))}
        </div>
      </Section>

      {/* ---------------- Compliance ---------------- */}
      <Section
        title="Compliance Checklist"
        subtitle="Vendors must confirm these (required items cannot be skipped)."
        onAdd={addCompliance}
        addLabel="+ Add Compliance Item"
      >
        <div className="grid gap-3">
          {model.complianceItems.map((c) => (
            <div key={c.id} className="flex flex-col gap-2 rounded-2xl border border-slate-200 bg-slate-50 p-4 md:flex-row md:items-center">
              <input
                value={c.text}
                onChange={(e) => updateCompliance(c.id, { text: e.target.value })}
                className={inputCls}
                placeholder="Compliance requirement"
              />
              <label className="flex items-center gap-2 text-sm font-bold text-slate-700">
                <input
                  type="checkbox"
                  checked={!!c.required}
                  onChange={(e) => updateCompliance(c.id, { required: e.target.checked })}
                />
                Required
              </label>
              <button type="button" onClick={() => removeById("complianceItems", c.id)} className={smallBtn}>
                Remove
              </button>
            </div>
          ))}
        </div>
      </Section>

      {/* ---------------- Documents ---------------- */}
      <Section
        title="Document Requirements"
        subtitle="Define required uploads and due dates (e.g., COI 14 days before)."
        onAdd={addDocument}
        addLabel="+ Add Document"
      >
        <div className="grid gap-3">
          {model.documentRequirements.map((d) => (
            <div key={d.id} className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
              <div className="flex flex-col gap-3 md:flex-row md:items-center">
                <input
                  value={d.name}
                  onChange={(e) => updateDocument(d.id, { name: e.target.value })}
                  className={inputCls}
                  placeholder="Document name"
                />
                <input
                  value={d.dueBy ?? ""}
                  onChange={(e) => updateDocument(d.id, { dueBy: e.target.value })}
                  className={inputCls}
                  placeholder="Due by (e.g., 14 days before)"
                />
                <label className="flex items-center gap-2 text-sm font-bold text-slate-700">
                  <input
                    type="checkbox"
                    checked={!!d.required}
                    onChange={(e) => updateDocument(d.id, { required: e.target.checked })}
                  />
                  Required
                </label>
                <button type="button" onClick={() => removeById("documentRequirements", d.id)} className={smallBtn}>
                  Remove
                </button>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* ---------------- Payment ---------------- */}
      <section className="mt-6 rounded-[26px] border border-slate-200 bg-white p-6 shadow-sm">
        <div className="text-lg font-black text-slate-900">Payment Settings</div>
        <div className="mt-1 text-sm font-semibold text-slate-600">
          Deposit rules, refund policy, and late fee settings.
        </div>

        <div className="mt-5 grid gap-4 md:grid-cols-2">
          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
            <label className="flex items-center gap-2 text-sm font-bold text-slate-700">
              <input
                type="checkbox"
                checked={!!model.paymentSettings.requireDeposit}
                onChange={(e) =>
                  setModel(
                    bump({
                      ...model,
                      paymentSettings: {
                        ...model.paymentSettings,
                        requireDeposit: e.target.checked,
                      },
                    })
                  )
                }
              />
              Require deposit
            </label>

            <div className="mt-4 grid gap-3 md:grid-cols-2">
              <div>
                <div className="text-xs font-black text-slate-700">Deposit %</div>
                <input
                  className={`mt-2 ${inputCls}`}
                  value={String(model.paymentSettings.depositPercent ?? 0)}
                  onChange={(e) =>
                    setModel(
                      bump({
                        ...model,
                        paymentSettings: {
                          ...model.paymentSettings,
                          depositPercent: clamp(Number(e.target.value || 0), 0, 100),
                        },
                      })
                    )
                  }
                  inputMode="numeric"
                />
              </div>

              <div>
                <div className="text-xs font-black text-slate-700">Late fee ($)</div>
                <input
                  className={`mt-2 ${inputCls}`}
                  value={String(model.paymentSettings.lateFee ?? 0)}
                  onChange={(e) =>
                    setModel(
                      bump({
                        ...model,
                        paymentSettings: {
                          ...model.paymentSettings,
                          lateFee: clamp(Number(e.target.value || 0), 0, 999999),
                        },
                      })
                    )
                  }
                  inputMode="numeric"
                />
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
            <div className="text-xs font-black text-slate-700">Refund policy</div>
            <select
              className="mt-2 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-900"
              value={model.paymentSettings.refundPolicy}
              onChange={(e) =>
                setModel(
                  bump({
                    ...model,
                    paymentSettings: {
                      ...model.paymentSettings,
                      refundPolicy: e.target.value as RefundPolicy,
                    },
                  })
                )
              }
            >
              <option>No Refunds</option>
              <option>Full Refund</option>
              <option>Partial Refund</option>
              <option>Event Credits Only</option>
            </select>

            <div className="mt-4">
              <div className="text-xs font-black text-slate-700">Payment notes</div>
              <textarea
                className="mt-2 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-900"
                style={{ minHeight: 84 }}
                value={model.paymentSettings.paymentNotes ?? ""}
                onChange={(e) =>
                  setModel(
                    bump({
                      ...model,
                      paymentSettings: {
                        ...model.paymentSettings,
                        paymentNotes: e.target.value,
                      },
                    })
                  )
                }
                placeholder="Explain deposit deadlines, payment timing, refund details, etc."
              />
            </div>
          </div>
        </div>
      </section>

      {/* Bottom actions */}
      <div className="mt-8 flex flex-wrap items-center justify-end gap-2">
        <button
          type="button"
          onClick={() => navigate(`/organizer/events/${model.eventId}`)}
          className="rounded-2xl border border-slate-200 bg-white px-5 py-3 text-sm font-black text-slate-900 hover:bg-slate-50"
        >
          Back to Event
        </button>

        <button
          type="button"
          onClick={onSave}
          disabled={saving}
          className="rounded-2xl bg-indigo-600 px-5 py-3 text-sm font-black text-white disabled:opacity-60"
        >
          {saving ? "Saving…" : "Save Requirements"}
        </button>

        <button
          type="button"
          onClick={onSaveAndContinue}
          disabled={saving}
          className="rounded-2xl border border-slate-200 bg-white px-5 py-3 text-sm font-black text-slate-900 hover:bg-slate-50 disabled:opacity-60"
        >
          Save & Continue → Map Editor
        </button>
      </div>

      {/* ---------------- Save Template Modal ---------------- */}
      {saveModalOpen ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4">
          <div className="w-full max-w-lg rounded-3xl bg-white p-6 shadow-xl">
            <div className="text-lg font-black text-slate-900">Save as Template</div>
            <div className="mt-1 text-sm font-semibold text-slate-600">
              Save this configuration for future events.
            </div>

            <div className="mt-5">
              <div className="text-xs font-black text-slate-700">Template name *</div>
              <input
                value={tplName}
                onChange={(e) => setTplName(e.target.value)}
                className="mt-2 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-900"
                placeholder="e.g., My Annual Food Festival"
              />
            </div>

            <div className="mt-4">
              <div className="text-xs font-black text-slate-700">Description (optional)</div>
              <textarea
                value={tplDesc}
                onChange={(e) => setTplDesc(e.target.value)}
                className="mt-2 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-900"
                style={{ minHeight: 90 }}
                placeholder="Notes to help you remember what this template is for"
              />
            </div>

            <div className="mt-6 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setSaveModalOpen(false)}
                className="rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-black text-slate-900 hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={saveAsTemplate}
                className="rounded-2xl bg-indigo-600 px-4 py-2 text-sm font-black text-white"
              >
                Save Template
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

/* ---------------- Shared UI ---------------- */

function Section({
  title,
  subtitle,
  onAdd,
  addLabel,
  children,
}: {
  title: string;
  subtitle: string;
  onAdd: () => void;
  addLabel: string;
  children: React.ReactNode;
}) {
  return (
    <section className="mt-6 rounded-[26px] border border-slate-200 bg-white p-6 shadow-sm">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-lg font-black text-slate-900">{title}</div>
          <div className="mt-1 text-sm font-semibold text-slate-600">{subtitle}</div>
        </div>
        <button
          type="button"
          onClick={onAdd}
          className="rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-black text-slate-900 hover:bg-slate-50"
        >
          {addLabel}
        </button>
      </div>

      <div className="mt-5">{children}</div>
    </section>
  );
}

const inputCls =
  "w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-900";

const smallBtn =
  "rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-black text-slate-700 hover:bg-slate-50";
