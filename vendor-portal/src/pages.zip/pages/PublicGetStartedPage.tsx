import React, { useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

type Role = "vendor" | "organizer";

function TopNav() {
  return (
    <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/90 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <Link to="/" className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600" />
          <span className="text-lg font-black text-slate-900">VendorConnect</span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          <Link to="/events" className="text-sm font-bold text-slate-600 hover:text-slate-900">
            Events
          </Link>
          <Link to="/vendors" className="text-sm font-bold text-slate-600 hover:text-slate-900">
            Vendors
          </Link>
          <Link to="/pricing" className="text-sm font-bold text-slate-600 hover:text-slate-900">
            Pricing
          </Link>
        </nav>

        <div className="flex items-center gap-3">
          <Link
            to="/login"
            className="rounded-xl border border-slate-200 bg-white px-5 py-2 text-sm font-black text-slate-700 hover:bg-slate-50"
          >
            Sign in
          </Link>
        </div>
      </div>
    </header>
  );
}

function RoleCard({
  active,
  title,
  subtitle,
  bullets,
  icon,
  accent,
  onClick,
}: {
  active: boolean;
  title: string;
  subtitle: string;
  bullets: string[];
  icon: React.ReactNode;
  accent: "indigo" | "purple";
  onClick: () => void;
}) {
  const ring =
    accent === "indigo"
      ? "ring-indigo-500 border-indigo-200"
      : "ring-purple-500 border-purple-200";
  const dot = accent === "indigo" ? "bg-indigo-600" : "bg-purple-600";

  return (
    <button
      type="button"
      onClick={onClick}
      className={[
        "group w-full rounded-[28px] border bg-white p-7 text-left shadow-sm transition",
        "hover:shadow-md",
        active ? `ring-4 ${ring}` : "border-slate-200 ring-0",
      ].join(" ")}
    >
      <div className="flex items-start gap-5">
        <div className="grid h-14 w-14 place-items-center rounded-2xl bg-slate-50 ring-1 ring-slate-200">
          {icon}
        </div>

        <div className="min-w-0 flex-1">
          <div className="text-2xl font-black text-slate-900">{title}</div>
          <div className="mt-2 text-sm font-semibold leading-relaxed text-slate-600">{subtitle}</div>

          <ul className="mt-5 space-y-2">
            {bullets.map((b) => (
              <li key={b} className="flex items-start gap-3 text-sm font-semibold text-slate-700">
                <span className={`mt-2 h-2 w-2 shrink-0 rounded-full ${dot}`} />
                <span>{b}</span>
              </li>
            ))}
          </ul>

          {active ? (
            <div className="mt-6 inline-flex items-center gap-2 text-sm font-black text-slate-900">
              <span className="grid h-7 w-7 place-items-center rounded-full bg-slate-900 text-white">
                ✓
              </span>
              Selected
            </div>
          ) : null}
        </div>
      </div>
    </button>
  );
}

export default function PublicGetStartedPage() {
  const navigate = useNavigate();
  const [role, setRole] = useState<Role | null>(null);

  const canContinue = !!role;

  const headerText = useMemo(() => {
    return role === "organizer" ? "Create Organizer Account" : "Create Your Account";
  }, [role]);

  return (
    <div className="min-h-screen bg-white">
      <TopNav />

      <section className="bg-gradient-to-br from-indigo-50 via-white to-purple-50">
        <div className="mx-auto max-w-7xl px-6 py-14">
          <div className="mx-auto max-w-4xl text-center">
            <div className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-5 py-2 text-sm font-black text-slate-700 shadow-sm">
              <span className="grid h-6 w-6 place-items-center rounded-full bg-indigo-600 text-white">
                🛡️
              </span>
              Verified Partners Only
            </div>

            <h1 className="mt-8 text-5xl font-black tracking-tight text-slate-900">
              {headerText}
            </h1>
            <p className="mt-4 text-base font-semibold text-slate-600">
              Join VendorConnect&apos;s trusted marketplace of verified organizers and vendors
            </p>
          </div>

          <div className="mx-auto mt-12 grid max-w-5xl gap-8 md:grid-cols-2">
            <RoleCard
              active={role === "vendor"}
              title="Vendor"
              subtitle="Apply to events, manage your business profile, and book booths."
              bullets={[
                "Browse verified events",
                "Interactive booth selection",
                "Showcase your portfolio",
                "Secure payment processing",
              ]}
              accent="indigo"
              icon={
                <svg viewBox="0 0 24 24" className="h-7 w-7" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M3 9l9-6 9 6v11a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9Z" />
                  <path d="M9 22V12h6v10" />
                </svg>
              }
              onClick={() => setRole("vendor")}
            />

            <RoleCard
              active={role === "organizer"}
              title="Organizer"
              subtitle="Create events, manage vendors, sell booth space, and accept payments."
              bullets={[
                "Create unlimited events",
                "Custom booth layouts",
                "Vendor applications management",
                "Payment & analytics dashboard",
              ]}
              accent="purple"
              icon={
                <svg viewBox="0 0 24 24" className="h-7 w-7" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M8 2v3M16 2v3M3 9h18" />
                  <path d="M5 6h14a2 2 0 0 1 2 2v13a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2Z" />
                </svg>
              }
              onClick={() => setRole("organizer")}
            />
          </div>

          <div className="mx-auto mt-10 flex max-w-5xl flex-col items-center gap-4">
            <button
              type="button"
              disabled={!canContinue}
              onClick={() => navigate("/create-account", { state: { role } })}
              className={[
                "w-full max-w-md rounded-2xl px-8 py-4 text-base font-black text-white shadow-sm transition",
                canContinue
                  ? "bg-gradient-to-r from-indigo-600 to-purple-600 hover:opacity-95"
                  : "cursor-not-allowed bg-slate-300",
              ].join(" ")}
            >
              Continue
            </button>

            <div className="text-sm font-semibold text-slate-600">
              Already have an account?{" "}
              <Link to="/login" className="font-black text-indigo-700 hover:text-indigo-800">
                Sign in
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
