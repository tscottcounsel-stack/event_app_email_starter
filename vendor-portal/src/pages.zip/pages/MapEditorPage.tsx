import React, { useEffect } from "react";
import { Navigate, useParams } from "react-router-dom";
import BoothMapEditor from "../figma/pages/BoothMapEditor";

/**
 * Organizer Map Editor wrapper
 * - Forces a full-screen layout so the editor fits like the vendor pages (no double scroll / clipped viewport)
 * - Ensures eventId exists in the querystring for BoothMapEditor (which reads window.location.search)
 */
export default function MapEditorPage() {
  const { eventId } = useParams<{ eventId: string }>();

  if (!eventId) return <Navigate to="/organizer/dashboard" replace />;

  useEffect(() => {
    const url = new URL(window.location.href);
    if (url.searchParams.get("eventId") !== eventId) {
      url.searchParams.set("eventId", eventId);
      window.history.replaceState({}, "", url.toString());
    }
  }, [eventId]);

  return (
    <div className="fixed inset-0 z-[60] bg-white">
      <div className="h-full w-full overflow-hidden">
        <BoothMapEditor key={eventId} />
      </div>
    </div>
  );
}
