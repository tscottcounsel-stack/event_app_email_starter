import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";

type OrganizerEvent = {
  id: number | string;
  title?: string;
  name?: string;

  // Backend flags (from your updated events.py)
  archived?: boolean;
  published?: boolean;
  layout_published?: boolean;

  // Optional fields
  start_date?: string;
  end_date?: string;
  venue_name?: string;
  city?: string;
  state?: string;
};

const API_BASE = (import.meta as any).env?.VITE_API_BASE || "http://127.0.0.1:8002";

function normalizeId(v: any) {
  return String(v ?? "").trim();
}

function safeDate(d?: string) {
  if (!d) return "";
  // Accept ISO strings from backend
  const dt = new Date(d);
  if (Number.isNaN(dt.getTime())) return String(d);
  return dt.toLocaleDateString();
}

function eventMeta(ev: OrganizerEvent) {
  const dates =
    ev.start_date || ev.end_date
      ? `${safeDate(ev.start_date)}${ev.end_date ? ` - ${safeDate(ev.end_date)}` : ""}`
      : "—";

  const venueLine = [ev.venue_name, ev.city, ev.state].filter(Boolean).join(" • ");
  return { dates, venueLine: venueLine || "—" };
}

function statusLabel(ev: OrganizerEvent) {
  if (ev.archived) return "Archived";
  if (ev.published) return "Published";
  return "Draft";
}

function statusClasses(ev: OrganizerEvent) {
  if (ev.archived) return "bg-slate-100 text-slate-700";
  if (ev.published) return "bg-emerald-50 text-emerald-700";
  return "bg-amber-50 text-amber-700";
}

async function getJson<T>(path: string): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "GET",
    headers: { Accept: "application/json" },
  });
  if (!res.ok) throw new Error(`Request failed (${res.status})`);
  return (await res.json()) as T;
}

async function postJson<T>(path: string, body?: any): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });

  const ct = res.headers.get("content-type") || "";
  const isJson = ct.includes("application/json");
  const data = isJson ? await res.json().catch(() => null) : await res.text().catch(() => null);

  if (!res.ok) {
    const msg =
      (isJson && data && (data.detail || data.message || data.error)) ||
      (typeof data === "string" ? data : null) ||
      `Request failed (${res.status})`;
    throw new Error(msg);
  }

  return data as T;
}

function hasRequirementsInLocalStorage(eventId: string) {
  // Your organizer requirements builder saves here (per your earlier debug keys)
  const key = `organizer:event:${eventId}:requirements`;
  return Boolean(localStorage.getItem(key));
}

export default function OrganizerEventsPage() {
  const navigate = useNavigate();

  const [loading, setLoading] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [events, setEvents] = useState<OrganizerEvent[]>([]);

  async function load() {
    setLoading(true);
    setError(null);

    try {
      // Your backend includes GET /events (from events.py). Organizer wrapper routes may also exist.
      const candidates = ["/events", "/organizer/events", "/api/events", "/api/organizer/events"];

      let data: any = null;
      let lastErr: any = null;

      for (const p of candidates) {
        try {
          data = await getJson<any>(p);
          break;
        } catch (e) {
          lastErr = e;
        }
      }

      const list: OrganizerEvent[] =
        (Array.isArray(data) ? data : null) ??
        (Array.isArray(data?.events) ? data.events : null) ??
        (Array.isArray(data?.items) ? data.items : null) ??
        [];

      if (!Array.isArray(list)) throw lastErr || new Error("Events response was not a list.");

      setEvents(list);
    } catch (e: any) {
      setError(e?.message || "Unable to load events.");
      setEvents([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  const rows = useMemo(() => {
    return (events || []).map((ev) => {
      const id = normalizeId(ev.id);
      const title = ev.title || ev.name || `Event ${id}`;
      const { dates, venueLine } = eventMeta(ev);
      const status = statusLabel(ev);
      return { id, title, status, dates, venueLine, ev };
    });
  }, [events]);

  async function publish(id: string) {
    setBusyId(id);
    setError(null);
    try {
      await postJson(`/events/${encodeURIComponent(id)}/publish`);
      await load();
    } catch (e: any) {
      setError(e?.message || "Publish failed.");
    } finally {
      setBusyId(null);
    }
  }

  async function unpublish(id: string) {
    setBusyId(id);
    setError(null);
    try {
      await postJson(`/events/${encodeURIComponent(id)}/unpublish`);
      await load();
    } catch (e: any) {
      setError(e?.message || "Unpublish failed.");
    } finally {
      setBusyId(null);
    }
  }

  function continueFlow(eventId: string) {
    // If requirements exist, go to map editor; otherwise, go to requirements builder.
    if (hasRequirementsInLocalStorage(eventId)) {
      navigate(`/organizer/events/${encodeURIComponent(eventId)}/layout`);
    } else {
      navigate(`/organizer/events/${encodeURIComponent(eventId)}/requirements`);
    }
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="mx-auto w-full max-w-6xl px-4 py-8">
        {/* Header */}
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <div className="text-3xl font-black text-slate-900">Events</div>
              <div className="mt-1 text-sm font-semibold text-slate-600">
                Edit event details, set requirements, publish, and build layouts.
              </div>
              <div className="mt-1 text-xs text-slate-500">
                API: <span className="font-mono">{API_BASE}</span>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={load}
                className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-black text-slate-800 hover:bg-slate-100"
              >
                Refresh
              </button>

              <button
                type="button"
                onClick={() => navigate("/organizer/events/create")}
                className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-black text-white hover:opacity-95"
              >
                + Create Event
              </button>
            </div>
          </div>
        </div>

        {/* Body */}
        <div className="mt-6 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="text-xl font-black text-slate-900">Your events</div>

          {error ? (
            <div className="mt-4 rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm font-semibold text-rose-700">
              {error}
            </div>
          ) : null}

          {loading ? (
            <div className="mt-4 flex items-center gap-3 text-sm font-semibold text-slate-700">
              <div className="h-4 w-4 animate-spin rounded-full border-2 border-slate-200 border-t-slate-700" />
              Loading…
            </div>
          ) : null}

          {!loading && rows.length === 0 ? (
            <div className="mt-4 rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm font-semibold text-slate-700">
              No events yet. Click <span className="font-black">Create Event</span> to get started.
            </div>
          ) : null}

          <div className="mt-4 grid gap-4">
            {rows.map(({ id, title, dates, venueLine, ev }) => {
              const status = statusLabel(ev);
              const isBusy = busyId === id;
              const reqExists = hasRequirementsInLocalStorage(id);

              return (
                <div key={id} className="rounded-2xl border border-slate-200 bg-white p-5">
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <div className="text-lg font-black text-slate-900">{title}</div>

                      <div className="mt-1 text-sm font-semibold text-slate-600">
                        <span className="mr-2">{dates}</span>
                        <span className="opacity-60">•</span>
                        <span className="ml-2">{venueLine}</span>
                      </div>

                      <div className="mt-2 text-xs text-slate-500">
                        Requirements:{" "}
                        <span className={reqExists ? "font-black text-emerald-700" : "font-black text-amber-700"}>
                          {reqExists ? "Saved" : "Not saved"}
                        </span>
                        {ev.layout_published ? (
                          <>
                            {" "}
                            • Layout: <span className="font-black text-emerald-700">Published</span>
                          </>
                        ) : (
                          <>
                            {" "}
                            • Layout: <span className="font-black text-slate-600">Not published</span>
                          </>
                        )}
                      </div>
                    </div>

                    <div className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-black ${statusClasses(ev)}`}>
                      {status}
                    </div>
                  </div>

                  <div className="mt-4 flex flex-wrap gap-2">
                    {/* Continue */}
                    <button
                      type="button"
                      onClick={() => continueFlow(id)}
                      className="rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 px-4 py-2 text-sm font-black text-white hover:opacity-95"
                    >
                      {reqExists ? "Continue → Layout" : "Continue → Requirements"}
                    </button>

                    {/* Edit */}
                    <button
                      type="button"
                      onClick={() => navigate(`/organizer/events/${encodeURIComponent(id)}/details`)}
                      className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-black text-slate-800 hover:bg-slate-100"
                    >
                      Edit
                    </button>

                    {/* Requirements */}
                    <button
                      type="button"
                      onClick={() => navigate(`/organizer/events/${encodeURIComponent(id)}/requirements`)}
                      className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-black text-slate-800 hover:bg-slate-100"
                    >
                      Requirements
                    </button>

                    {/* Layout */}
                    <button
                      type="button"
                      onClick={() => navigate(`/organizer/events/${encodeURIComponent(id)}/layout`)}
                      className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-black text-slate-800 hover:bg-slate-100"
                    >
                      View Layout
                    </button>

                    {/* Publish / Unpublish */}
                    {!ev.archived ? (
                      ev.published ? (
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => unpublish(id)}
                          className={`rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-black text-slate-800 hover:bg-slate-100 ${
                            isBusy ? "opacity-60" : ""
                          }`}
                        >
                          {isBusy ? "Working…" : "Unpublish"}
                        </button>
                      ) : (
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => publish(id)}
                          className={`rounded-xl bg-slate-900 px-4 py-2 text-sm font-black text-white hover:opacity-95 ${
                            isBusy ? "opacity-60" : ""
                          }`}
                        >
                          {isBusy ? "Publishing…" : "Publish to Vendors"}
                        </button>
                      )
                    ) : null}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
