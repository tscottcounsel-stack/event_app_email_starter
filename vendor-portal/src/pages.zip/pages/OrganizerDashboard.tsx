import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";

type OrganizerProfile = {
  company_name?: string;
  display_name?: string;
  name?: string;
  email?: string;
};

type EventRow = {
  id: number;
  name?: string;
  title?: string;
  start_date?: string; // ISO
  end_date?: string; // ISO
  venue_name?: string;
  location?: string;
  city?: string;
  state?: string;
  zip?: string;
  status?: string; // "draft" | "active" | "published" etc
};

type ApplicationRow = {
  id: number;
  event_id?: number;
  status?: string;
  vendor_id?: number;
  vendor_name?: string;
  vendor_company?: string;
  business_name?: string;
  created_at?: string;
};

const API_BASE = import.meta.env.VITE_API_BASE_URL || "http://localhost:8002";

async function apiJson(path: string, init?: RequestInit) {
  const url = path.startsWith("http") ? path : `${API_BASE}${path}`;
  const res = await fetch(url, {
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers || {}),
    },
    ...init,
  });

  if (!res.ok) {
    let msg = `Request failed (${res.status})`;
    try {
      const data = await res.json();
      msg = data?.detail ? JSON.stringify(data.detail) : JSON.stringify(data);
    } catch {}
    const err: any = new Error(msg);
    err.status = res.status;
    throw err;
  }

  try {
    return await res.json();
  } catch {
    return null;
  }
}

function fmtDateRange(start?: string, end?: string) {
  if (!start && !end) return "—";
  try {
    const s = start ? new Date(start) : null;
    const e = end ? new Date(end) : null;
    const opts: Intl.DateTimeFormatOptions = { month: "numeric", day: "numeric", year: "numeric" };

    if (s && e)
      return `${s.toLocaleDateString(undefined, opts)} - ${e.toLocaleDateString(undefined, opts)}`;
    if (s) return s.toLocaleDateString(undefined, opts);
    if (e) return e.toLocaleDateString(undefined, opts);
  } catch {}
  return "—";
}

function firstNonEmpty(...vals: Array<string | undefined | null>) {
  for (const v of vals) if (v && String(v).trim()) return String(v);
  return "";
}

function StatusPill({ status }: { status?: string }) {
  const s = (status || "draft").toLowerCase();
  const label = s === "active" ? "Active" : s === "published" ? "Published" : "Draft";
  const tone =
    s === "active" || s === "published"
      ? "bg-emerald-50 text-emerald-700 ring-emerald-200"
      : "bg-amber-50 text-amber-700 ring-amber-200";

  return (
    <span className={`inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-semibold ring-1 ${tone}`}>
      <span className="h-2 w-2 rounded-full bg-current opacity-60" />
      {label}
    </span>
  );
}

function StatCard({
  title,
  value,
  icon,
}: {
  title: string;
  value: number;
  icon: string;
}) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-sm font-semibold text-slate-600">{title}</div>
          <div className="mt-2 text-3xl font-extrabold text-slate-900">{value}</div>
        </div>
        <div className="rounded-2xl bg-slate-50 p-3 ring-1 ring-slate-100">
          <span className="text-xl" aria-hidden>
            {icon}
          </span>
        </div>
      </div>
    </div>
  );
}

// Persist “this endpoint does not exist” decisions to stop 404 spam in dev (StrictMode double-invokes effects).
const SUPPORTS_ORG_EVENTS_KEY = "supports_org_events_v1";
const SUPPORTS_ORG_APPS_PER_EVENT_KEY = "supports_org_apps_per_event_v1";

function getSupportFlag(key: string): "unknown" | "yes" | "no" {
  const v = sessionStorage.getItem(key);
  if (v === "yes" || v === "no") return v;
  return "unknown";
}
function setSupportFlag(key: string, val: "yes" | "no") {
  sessionStorage.setItem(key, val);
}

export default function OrganizerDashboard() {
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string>("");

  // Profile is optional and currently 404s in your backend (router file was overwritten),
  // so we keep it local but DO NOT call /organizer/profile anymore to avoid spam.
  const [profile] = useState<OrganizerProfile>({});

  const [events, setEvents] = useState<EventRow[]>([]);

  // Pending apps (dashboard section)
  const [pendingAppsLoading, setPendingAppsLoading] = useState(false);
  const [pendingApps, setPendingApps] = useState<ApplicationRow[]>([]);

  // Contact module (placeholder counts until contacts router is restored)
  const [contactCount] = useState<number>(0);
  const [selectedContacts] = useState<number>(0);

  const welcomeName = useMemo(() => {
    const raw = firstNonEmpty(profile.company_name, profile.display_name, profile.name, "Organizer");
    return raw.toUpperCase();
  }, [profile.company_name, profile.display_name, profile.name]);

  const stats = useMemo(() => {
    const total = events.length;
    const active = events.filter((e) => (e.status || "").toLowerCase() === "active").length;
    const draft = events.filter((e) => (e.status || "").toLowerCase() === "draft").length;
    const pending = pendingApps.length;
    return { total, active, draft, pending };
  }, [events, pendingApps]);

  async function loadAll(isRefresh = false) {
    try {
      setError("");
      if (isRefresh) setRefreshing(true);
      else setLoading(true);

      // -------------------------
      // Events
      // -------------------------
      // Try /organizer/events once (if it exists). If it 404s, remember that and use /events without spamming.
      let evData: any = null;
      const orgEventsSupport = getSupportFlag(SUPPORTS_ORG_EVENTS_KEY);

      if (orgEventsSupport !== "no") {
        try {
          evData = await apiJson("/organizer/events", { method: "GET" });
          setSupportFlag(SUPPORTS_ORG_EVENTS_KEY, "yes");
        } catch (e: any) {
          if (e?.status === 404) {
            setSupportFlag(SUPPORTS_ORG_EVENTS_KEY, "no");
          }
        }
      }

      if (!evData) {
        // This is working in your app now, so we keep it as the reliable fallback.
        evData = await apiJson("/events", { method: "GET" });
      }

      const list = evData?.events || evData?.data || evData || [];
      const eventList: EventRow[] = Array.isArray(list) ? list : [];
      setEvents(eventList);

      // -------------------------
      // Pending applications (per-event endpoint)
      // -------------------------
      // Your backend supports: GET /organizer/events/{event_id}/applications
      // (NOT /organizer/applications). If the router isn't mounted, it will 404; we detect once and stop calling.
      setPendingAppsLoading(true);
      try {
        const appsSupport = getSupportFlag(SUPPORTS_ORG_APPS_PER_EVENT_KEY);
        if (appsSupport === "no") {
          setPendingApps([]);
          return;
        }

        const allPending: ApplicationRow[] = [];

        // Small, safe loop (usually low event counts on dashboard)
        for (const ev of eventList) {
          try {
            const a: any = await apiJson(`/organizer/events/${ev.id}/applications`, { method: "GET" });
            setSupportFlag(SUPPORTS_ORG_APPS_PER_EVENT_KEY, "yes");

            const apps: ApplicationRow[] =
              (Array.isArray(a?.applications) ? a.applications : null) ||
              (Array.isArray(a?.data) ? a.data : null) ||
              (Array.isArray(a) ? a : []);

            for (const app of apps) {
              const status = (app.status || "").toLowerCase();
              if (status === "pending") {
                allPending.push({ ...app, event_id: app.event_id ?? ev.id });
              }
            }
          } catch (e: any) {
            if (e?.status === 404) {
              // Router not mounted — remember and stop spamming.
              setSupportFlag(SUPPORTS_ORG_APPS_PER_EVENT_KEY, "no");
              setPendingApps([]);
              break;
            }
            // Non-404 errors: ignore per event so dashboard still renders.
          }
        }

        setPendingApps(allPending);
      } finally {
        setPendingAppsLoading(false);
      }
    } catch (e: any) {
      setError(e?.message || "Failed to load dashboard.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  useEffect(() => {
    loadAll(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function handleSignOut() {
    apiJson("/auth/logout", { method: "POST" })
      .catch(() => null)
      .finally(() => {
        navigate("/login");
      });
  }

  return (
    <div className="mx-auto w-full max-w-6xl px-4 pb-16 pt-8">
      {/* Top header bar */}
      <div className="mb-6 flex items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="rounded-2xl bg-indigo-600 p-3 text-white shadow-sm">
            <span aria-hidden className="text-xl">
              👤
            </span>
          </div>
          <div>
            <h1 className="text-3xl font-extrabold tracking-tight text-slate-900">Organizer Dashboard</h1>
            <div className="mt-1 text-sm font-semibold text-slate-600">
              Welcome back,
              <span className="ml-2 font-extrabold text-slate-900">{welcomeName}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => loadAll(true)}
            className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700 shadow-sm hover:bg-slate-50"
            disabled={refreshing}
          >
            {refreshing ? "Refreshing…" : "Refresh"}
          </button>
          <button
            onClick={handleSignOut}
            className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700 shadow-sm hover:bg-slate-50"
          >
            Sign Out
          </button>
        </div>
      </div>

      {error ? (
        <div className="mb-6 rounded-2xl border border-rose-200 bg-rose-50 p-4 text-sm font-semibold text-rose-800">
          {error}
        </div>
      ) : null}

      {/* Stats */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard title="Total Events" value={stats.total} icon="🗓️" />
        <StatCard title="Pending Applications" value={stats.pending} icon="👥" />
        <StatCard title="Active Events" value={stats.active} icon="✅" />
        <StatCard title="Draft Events" value={stats.draft} icon="📝" />
      </div>

      {/* Upcoming / Events table */}
      <div className="mt-8 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <div className="text-lg font-extrabold text-slate-900">Your Events</div>
            <div className="text-sm font-semibold text-slate-600">
              Open an event to view details, applications, or layout.
            </div>
          </div>

          <button
            onClick={() => navigate("/organizer/events")}
            className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-slate-800"
          >
            View All
          </button>
        </div>

        {loading ? (
          <div className="py-10 text-center text-sm font-semibold text-slate-600">Loading…</div>
        ) : events.length === 0 ? (
          <div className="py-10 text-center text-sm font-semibold text-slate-600">
            No events yet. Create one to get started.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-separate border-spacing-y-2">
              <thead>
                <tr className="text-left text-xs font-extrabold uppercase tracking-wide text-slate-500">
                  <th className="px-3 py-2">Event</th>
                  <th className="px-3 py-2">Dates</th>
                  <th className="px-3 py-2">Status</th>
                  <th className="px-3 py-2 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {events.slice(0, 6).map((ev) => {
                  const name = firstNonEmpty(ev.title, ev.name, `Event #${ev.id}`);
                  return (
                    <tr key={ev.id} className="rounded-2xl bg-slate-50">
                      <td className="px-3 py-3">
                        <div className="font-extrabold text-slate-900">{name}</div>
                        <div className="text-sm font-semibold text-slate-600">
                          {firstNonEmpty(ev.venue_name, ev.location, ev.city, ev.state) || "—"}
                        </div>
                      </td>
                      <td className="px-3 py-3 text-sm font-semibold text-slate-700">
                        {fmtDateRange(ev.start_date, ev.end_date)}
                      </td>
                      <td className="px-3 py-3">
                        <StatusPill status={ev.status} />
                      </td>
                      <td className="px-3 py-3">
                        <div className="flex justify-end gap-2">
                          <button
                            onClick={() => navigate(`/organizer/events/${ev.id}/details`)}
                            className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-800 hover:bg-slate-50"
                          >
                            Open
                          </button>
                          <button
                            onClick={() => navigate(`/organizer/events/${ev.id}/layout`)}
                            className="rounded-xl bg-indigo-600 px-3 py-2 text-sm font-semibold text-white hover:bg-indigo-500"
                          >
                            Layout
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Pending applications quick list */}
      <div className="mt-8 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <div className="text-lg font-extrabold text-slate-900">Pending Applications</div>
            <div className="text-sm font-semibold text-slate-600">
              Pulled from per-event applications endpoint.
            </div>
          </div>
          <button
            onClick={() => navigate("/organizer/events")}
            className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700 shadow-sm hover:bg-slate-50"
          >
            Manage
          </button>
        </div>

        {pendingAppsLoading ? (
          <div className="py-6 text-center text-sm font-semibold text-slate-600">Loading…</div>
        ) : pendingApps.length === 0 ? (
          <div className="py-6 text-center text-sm font-semibold text-slate-600">No pending applications.</div>
        ) : (
          <div className="divide-y divide-slate-100">
            {pendingApps.slice(0, 6).map((a) => (
              <div key={a.id} className="flex items-center justify-between py-3">
                <div>
                  <div className="font-extrabold text-slate-900">
                    {firstNonEmpty(
                      a.vendor_name,
                      a.vendor_company,
                      a.business_name,
                      `Vendor #${a.vendor_id || "—"}`
                    )}
                  </div>
                  <div className="text-sm font-semibold text-slate-600">
                    Application #{a.id} • Event {a.event_id ?? "—"}
                  </div>
                </div>
                <button
                  onClick={() => navigate(`/organizer/vendor-preview/${a.id}`)}
                  className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-800"
                >
                  Review
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ✅ Contact Management module (matches your Figma bottom section) */}
      <div className="mt-8 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <div className="text-lg font-extrabold text-slate-900">Contact Management</div>
            <div className="text-sm font-semibold text-slate-600">
              Manage contacts for outreach and invitations.
            </div>
            <div className="mt-1 text-xs font-semibold text-slate-500">
              {contactCount} total contacts • {selectedContacts} selected
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => navigate("/organizer/contacts")}
              className="rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-500"
            >
              + Add Contact
            </button>

            <button
              onClick={() => navigate("/organizer/contacts")}
              className="rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-500"
            >
              Import CSV
            </button>

            <button
              onClick={() => navigate("/organizer/contacts")}
              className="rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-500"
            >
              Export CSV
            </button>
          </div>
        </div>

        <div className="mt-5 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div className="w-full md:max-w-xs">
            <label className="sr-only">Event Filter</label>
            <select className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-800">
              <option>All Events</option>
            </select>
          </div>

          <div className="flex flex-wrap gap-2">
            <button className="rounded-xl bg-emerald-100 px-4 py-2 text-sm font-semibold text-emerald-800 hover:bg-emerald-200">
              ✓ Select All
            </button>
            <button className="rounded-xl bg-indigo-100 px-4 py-2 text-sm font-semibold text-indigo-800 hover:bg-indigo-200">
              ✉ Email (0)
            </button>
            <button className="rounded-xl bg-indigo-100 px-4 py-2 text-sm font-semibold text-indigo-800 hover:bg-indigo-200">
              💬 Text (0)
            </button>
          </div>
        </div>

        <div className="mt-6 rounded-2xl border border-slate-200 bg-white p-4">
          <div className="text-sm font-extrabold text-slate-900">Contacts</div>
          <div className="mt-2 text-sm font-semibold text-slate-600">No contacts yet.</div>
        </div>
      </div>
    </div>
  );
}
