import React from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";

function NavItem({
  to,
  label,
  icon,
}: {
  to: string;
  label: string;
  icon: React.ReactNode;
}) {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        [
          "flex items-center gap-3 rounded-xl px-3 py-2 font-medium transition",
          "text-base",
          isActive
            ? "bg-slate-100 text-slate-900"
            : "text-slate-700 hover:bg-slate-50 hover:text-slate-900",
        ].join(" ")
      }
    >
      <span className="grid h-10 w-10 place-items-center rounded-xl border border-slate-200 bg-white">
        {icon}
      </span>
      <span>{label}</span>
    </NavLink>
  );
}

export default function OrganizerLayout() {
  const navigate = useNavigate();

  function handleSignOut() {
    localStorage.removeItem("accessToken");
    localStorage.removeItem("userRole");
    localStorage.removeItem("userEmail");
    navigate("/login");
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="flex gap-6 p-6">
        {/* Sidebar */}
        <aside className="hidden w-72 shrink-0 md:block">
          <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="mb-5">
              <div className="text-xl font-extrabold text-slate-900">Organizer</div>
              <div className="mt-1 text-sm font-semibold text-slate-600">Welcome back</div>
            </div>

            <nav className="space-y-2">
              <NavItem
                to="/organizer/dashboard"
                label="Dashboard"
                icon={
                  <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M3 13h8V3H3v10Zm10 8h8V11h-8v10ZM13 3h8v6h-8V3ZM3 17h8v4H3v-4Z" />
                  </svg>
                }
              />

              <NavItem
                to="/organizer/events"
                label="Events"
                icon={
                  <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M8 2v3M16 2v3M3 9h18" />
                    <path d="M5 6h14a2 2 0 0 1 2 2v13a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2Z" />
                  </svg>
                }
              />

              {/* Per your spec: do NOT show Applications in sidebar */}
              <NavItem
                to="/organizer/contacts"
                label="Contacts"
                icon={
                  <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M17 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2" />
                    <path d="M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z" />
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                    <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                  </svg>
                }
              />

              <NavItem
                to="/organizer/profile"
                label="Organizer Profile"
                icon={
                  <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M20 21a8 8 0 1 0-16 0" />
                    <path d="M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z" />
                  </svg>
                }
              />

              <NavItem
                to="/organizer/messages"
                label="Messaging"
                icon={
                  <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4v8Z" />
                  </svg>
                }
              />
            </nav>
          </div>
        </aside>

        {/* Main content */}
        <main className="min-w-0 flex-1">
          <div className="flex items-center justify-end">
            <button
              type="button"
              onClick={handleSignOut}
              className="rounded-full border border-slate-200 bg-white px-5 py-2 text-sm font-extrabold text-slate-700 hover:bg-slate-50"
            >
              Sign out
            </button>
          </div>

          <div className="mt-6">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
