import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

type EventDetails = {
  id: number | string;
  title?: string;
  description?: string;

  start_date?: string;
  end_date?: string;

  venue_name?: string;
  street_address?: string;
  city?: string;
  state?: string;
  zip_code?: string;
  google_maps_url?: string;

  category?: string;
  expected_attendees?: number;
  setup_time?: string;
  additional_notes?: string;

  status?: string; // Draft/Published/Archived etc
};

const API_BASE = (import.meta as any).env?.VITE_API_BASE || "http://127.0.0.1:8002";

function normalizeId(v: any) {
  return String(v ?? "").trim();
}

function prettyStatus(s?: string) {
  const v = String(s || "").toLowerCase();
  if (v.includes("draft")) return "Draft";
  if (v.includes("publish")) return "Published";
  if (v.includes("archive")) return "Archived";
  return s ? s : "Draft";
}

async function getJson<T>(path: string): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "GET",
    headers: { Accept: "application/json" },
  });
  if (!res.ok) throw new Error(`Request failed (${res.status})`);
  return (await res.json()) as T;
}

async function patchJson<T>(path: string, body: any): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify(body),
  });
  const ct = res.headers.get("content-type") || "";
  const data = ct.includes("application/json") ? await res.json().catch(() => null) : await res.text().catch(() => null);
  if (!res.ok) throw new Error((typeof data === "string" && data) || `Request failed (${res.status})`);
  return data as T;
}

export default function OrganizerEventDetailsPage() {
  const navigate = useNavigate();
  const params = useParams();
  const eventId = useMemo(() => normalizeId(params.eventId), [params.eventId]);

  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [event, setEvent] = useState<EventDetails>({
    id: eventId,
    title: "",
    description: "",
    start_date: "",
    end_date: "",
    venue_name: "",
    street_address: "",
    city: "",
    state: "",
    zip_code: "",
    google_maps_url: "",
    category: "",
    expected_attendees: undefined,
    setup_time: "",
    additional_notes: "",
    status: "Draft",
  });

  async function load() {
    if (!eventId) {
      setError("Missing eventId.");
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const candidates = [
        `/events/${encodeURIComponent(eventId)}`,
        `/organizer/events/${encodeURIComponent(eventId)}`,
        `/api/events/${encodeURIComponent(eventId)}`,
        `/api/organizer/events/${encodeURIComponent(eventId)}`,
      ];

      let data: any = null;
      let lastErr: any = null;

      for (const p of candidates) {
        try {
          data = await getJson<any>(p);
          if (data) break;
        } catch (e) {
          lastErr = e;
        }
      }

      const rec = (data?.event ?? data) as any;
      if (!rec) throw lastErr || new Error("No event returned.");

      setEvent((prev) => ({
        ...prev,
        ...rec,
        id: rec.id ?? rec.event_id ?? prev.id ?? eventId,
      }));
    } catch (e: any) {
      setError(e?.message || "Unable to load event details.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [eventId]);

  const statusLabel = useMemo(() => prettyStatus(event.status), [event.status]);

  const update = <K extends keyof EventDetails>(key: K, value: EventDetails[K]) => {
    setEvent((prev) => ({ ...prev, [key]: value }));
  };

  async function onSave() {
    if (!eventId) return;
    setSaving(true);
    setError(null);
    try {
      const payload = { ...event };
      // you can remove id from payload if backend hates it
      await patchJson(`/events/${encodeURIComponent(eventId)}`, payload).catch(async () => {
        // fallback to organizer route if needed
        await patchJson(`/organizer/events/${encodeURIComponent(eventId)}`, payload);
      });
    } catch (e: any) {
      setError(e?.message || "Save failed.");
    } finally {
      setSaving(false);
    }
  }

  function goRequirements() {
    navigate(`/organizer/events/${encodeURIComponent(eventId)}/requirements`);
  }

  function goLayout() {
    navigate(`/organizer/events/${encodeURIComponent(eventId)}/layout`);
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="mx-auto w-full max-w-6xl px-4 py-8">
        {/* Top Bar */}
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <div className="text-3xl font-black text-slate-900">{event.title || "Event Details"}</div>
              <div className="mt-2 inline-flex items-center rounded-full bg-amber-50 px-3 py-1 text-xs font-black text-amber-700">
                {statusLabel}
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => navigate("/organizer/events")}
                className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-black text-slate-800 hover:bg-slate-100"
              >
                Back
              </button>

              <button
                type="button"
                onClick={onSave}
                disabled={saving}
                className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-black text-white hover:opacity-95 disabled:opacity-60"
              >
                {saving ? "Saving…" : "Save"}
              </button>

              <button
                type="button"
                onClick={goRequirements}
                className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-black text-slate-800 hover:bg-slate-100"
              >
                Requirements →
              </button>

              {/* ✅ THIS IS THE ONE YOU’RE MISSING */}
              <button
                type="button"
                onClick={goLayout}
                className="rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 px-4 py-2 text-sm font-black text-white hover:opacity-95"
              >
                Continue to Map Layout →
              </button>
            </div>
          </div>

          {error ? (
            <div className="mt-4 rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm font-semibold text-rose-700">
              {error}
            </div>
          ) : null}

          {loading ? (
            <div className="mt-4 flex items-center gap-3 text-sm font-semibold text-slate-700">
              <div className="h-4 w-4 animate-spin rounded-full border-2 border-slate-200 border-t-slate-700" />
              Loading…
            </div>
          ) : null}
        </div>

        {/* Form grid */}
        <div className="mt-6 grid gap-4 lg:grid-cols-2">
          {/* Event Details */}
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
            <div className="text-xl font-black text-slate-900">Event Details</div>

            <div className="mt-4 space-y-3">
              <input
                className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-900 outline-none focus:border-indigo-400"
                value={event.title ?? ""}
                onChange={(e) => update("title", e.target.value)}
                placeholder="Event name"
              />

              <textarea
                className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-900 outline-none focus:border-indigo-400"
                rows={5}
                value={event.description ?? ""}
                onChange={(e) => update("description", e.target.value)}
                placeholder="Description"
              />

              <div className="grid gap-3 sm:grid-cols-2">
                <input
                  type="datetime-local"
                  className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-900 outline-none focus:border-indigo-400"
                  value={event.start_date ?? ""}
                  onChange={(e) => update("start_date", e.target.value)}
                />
                <input
                  type="datetime-local"
                  className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-900 outline-none focus:border-indigo-400"
                  value={event.end_date ?? ""}
                  onChange={(e) => update("end_date", e.target.value)}
                />
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <input
                  className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-900 outline-none focus:border-indigo-400"
                  value={event.category ?? ""}
                  onChange={(e) => update("category", e.target.value)}
                  placeholder="Category"
                />
                <input
                  className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-900 outline-none focus:border-indigo-400"
                  value={event.expected_attendees?.toString() ?? ""}
                  onChange={(e) => update("expected_attendees", e.target.value ? Number(e.target.value) : undefined)}
                  placeholder="Expected attendees"
                />
              </div>

              <input
                className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-900 outline-none focus:border-indigo-400"
                value={event.setup_time ?? ""}
                onChange={(e) => update("setup_time", e.target.value)}
                placeholder="Setup time (optional)"
              />
            </div>
          </div>

          {/* Location */}
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
            <div className="text-xl font-black text-slate-900">Location</div>

            <div className="mt-4 space-y-3">
              <input
                className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-900 outline-none focus:border-indigo-400"
                value={event.venue_name ?? ""}
                onChange={(e) => update("venue_name", e.target.value)}
                placeholder="Venue name"
              />

              <input
                className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-900 outline-none focus:border-indigo-400"
                value={event.street_address ?? ""}
                onChange={(e) => update("street_address", e.target.value)}
                placeholder="Street address"
              />

              <div className="grid gap-3 sm:grid-cols-3">
                <input
                  className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-900 outline-none focus:border-indigo-400"
                  value={event.city ?? ""}
                  onChange={(e) => update("city", e.target.value)}
                  placeholder="City"
                />
                <input
                  className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-900 outline-none focus:border-indigo-400"
                  value={event.state ?? ""}
                  onChange={(e) => update("state", e.target.value)}
                  placeholder="State"
                />
                <input
                  className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-900 outline-none focus:border-indigo-400"
                  value={event.zip_code ?? ""}
                  onChange={(e) => update("zip_code", e.target.value)}
                  placeholder="ZIP"
                />
              </div>

              <input
                className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-900 outline-none focus:border-indigo-400"
                value={event.google_maps_url ?? ""}
                onChange={(e) => update("google_maps_url", e.target.value)}
                placeholder="Google Maps URL"
              />

              <textarea
                className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-900 outline-none focus:border-indigo-400"
                rows={4}
                value={event.additional_notes ?? ""}
                onChange={(e) => update("additional_notes", e.target.value)}
                placeholder="Additional notes"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
