import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

const API_BASE = import.meta.env.VITE_API_BASE || "http://127.0.0.1:8002";

function authHeaders() {
  const raw = sessionStorage.getItem("session");
  if (!raw) return { Accept: "application/json" };

  try {
    const s = JSON.parse(raw);
    return {
      Accept: "application/json",
      Authorization: `Bearer ${s.accessToken}`,
      "Content-Type": "application/json",
    };
  } catch {
    return { Accept: "application/json" };
  }
}

export default function VendorEventApplyPage() {
  const nav = useNavigate();
  const { eventId } = useParams();

  const [requirements, setRequirements] = useState<string[]>([]);
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!eventId) return;

    fetch(`${API_BASE}/events/${eventId}/requirements`)
      .then(r => r.json())
      .then(data => {
        setRequirements(data?.requirements || []);
      })
      .finally(() => setLoading(false));
  }, [eventId]);

  async function submit() {
    if (!eventId) return;

    const res = await fetch(
      `${API_BASE}/applications/events/${eventId}/apply`,
      {
        method: "POST",
        headers: authHeaders(),
        body: JSON.stringify({ notes }),
      }
    );

    if (!res.ok) {
      alert("Submit failed");
      return;
    }

    alert("Application submitted!");
    nav("/vendor/applications");
  }

  if (loading) return <div style={{ padding: 40 }}>Loading…</div>;

  return (
    <div style={{ padding: 40 }}>
      <h1>Apply to Event {eventId}</h1>

      <h3>Requirements</h3>
      {requirements.map((r, i) => (
        <label key={i} style={{ display: "block", marginBottom: 8 }}>
          <input type="checkbox" /> {r}
        </label>
      ))}

      <h3>Notes</h3>
      <textarea
        value={notes}
        onChange={e => setNotes(e.target.value)}
        style={{ width: 400, height: 120 }}
      />

      <br /><br />

      <button onClick={submit}>
        Submit Application
      </button>
    </div>
  );
}
