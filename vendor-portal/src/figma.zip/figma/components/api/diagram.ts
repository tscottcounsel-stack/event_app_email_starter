// src/figma/components/api/diagram.ts
import { readSession } from "../../../auth/authStorage";

const API_BASE = (import.meta as any).env?.VITE_API_BASE || "http://127.0.0.1:8002";

export type Booth = {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  label?: string;
  status?: string;
  category?: string;
  price?: number;
};

export type DiagramResponse = {
  diagram: any | null;
  version: number | null;
};

function authHeaders() {
  const s = readSession();
  const h: Record<string, string> = { Accept: "application/json" };
  if (s?.accessToken) h.Authorization = `Bearer ${s.accessToken}`;
  return h;
}

async function readBody(res: Response) {
  const ct = res.headers.get("content-type") || "";
  if (ct.includes("application/json")) return await res.json().catch(() => null);
  return await res.text().catch(() => "");
}

function errMsg(body: any, status: number) {
  if (typeof body === "string" && body.trim()) return body;
  if (body && typeof body === "object") return body.detail || body.message || JSON.stringify(body);
  return `Request failed (${status})`;
}

function normalizeDiagramResponse(body: any): DiagramResponse {
  // Expected backend shape:
  // { diagram: <any|null>, version: <number|null> }
  if (body && typeof body === "object" && ("diagram" in body || "version" in body)) {
    return {
      diagram: (body as any).diagram ?? null,
      version: (body as any).version ?? null,
    };
  }

  // Some older backends might return the diagram directly
  // If so, wrap it.
  return {
    diagram: body ?? null,
    version: null,
  };
}

function organizerDiagramUrl(eventId: string | number) {
  const id = encodeURIComponent(String(eventId));
  return `${API_BASE}/organizer/events/${id}/diagram`;
}

/**
 * Canonical organizer endpoints:
 * GET  /organizer/events/{event_id}/diagram
 * PUT  /organizer/events/{event_id}/diagram
 * POST /organizer/events/{event_id}/diagram (fallback only if PUT returns 405)
 */
export async function getEventDiagram(eventId: string | number): Promise<DiagramResponse> {
  const url = organizerDiagramUrl(eventId);

  const res = await fetch(url, { method: "GET", headers: authHeaders() });
  const body = await readBody(res);

  if (!res.ok) {
    // Make event-not-found super obvious in console
    if (res.status === 404) {
      throw new Error(`${url} → Event not found (eventId=${eventId}). Create the event first, then load the layout.`);
    }
    throw new Error(`${url} → ${errMsg(body, res.status)}`);
  }

  return normalizeDiagramResponse(body);
}

export async function saveEventDiagram(
  eventId: string | number,
  diagram: any,
  version?: number | null
): Promise<DiagramResponse> {
  const url = organizerDiagramUrl(eventId);
  const payload = { diagram, version: version ?? null };

  // Try PUT first (canonical)
  {
    const res = await fetch(url, {
      method: "PUT",
      headers: { ...authHeaders(), "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const body = await readBody(res);

    // If server doesn't allow PUT, fall back to POST (some setups do that)
    if (res.status !== 405) {
      if (!res.ok) {
        if (res.status === 404) {
          throw new Error(`${url} → Event not found (eventId=${eventId}). Create the event first, then save layout.`);
        }
        throw new Error(`PUT ${url} → ${errMsg(body, res.status)}`);
      }
      return normalizeDiagramResponse(body);
    }
  }

  // Fallback: POST only if PUT is not allowed
  {
    const res = await fetch(url, {
      method: "POST",
      headers: { ...authHeaders(), "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const body = await readBody(res);

    if (!res.ok) {
      if (res.status === 404) {
        throw new Error(`${url} → Event not found (eventId=${eventId}). Create the event first, then save layout.`);
      }
      throw new Error(`POST ${url} → ${errMsg(body, res.status)}`);
    }

    return normalizeDiagramResponse(body);
  }
}
