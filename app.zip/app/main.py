# app/main.py

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.routers.auth import router as auth_router
from app.routers.events import router as events_router
from app.routers.requirements import router as requirements_router
from app.routers.templates import router as templates_router
from app.routers.booths import router as booths_router
from app.routers.layout import router as layout_router
from app.routers.organizer_applications import router as organizer_applications_router
from app.routers.organizer_diagram import router as organizer_diagram_router

app = FastAPI(title="Event App API", version="0.1.0")

# CORS for Vite dev server
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health", tags=["default"])
def health():
    return {"status": "ok"}


# ---------------- Routers ----------------
# NOTE: prefix="" keeps endpoints as documented (e.g. POST /login)
app.include_router(auth_router, prefix="", tags=["Auth"])
app.include_router(events_router, prefix="", tags=["Events"])
app.include_router(requirements_router, prefix="", tags=["Requirements"])
app.include_router(templates_router, prefix="", tags=["Templates"])
app.include_router(booths_router, prefix="", tags=["Booths"])
app.include_router(layout_router, prefix="", tags=["Layout"])

# Organizer Applications router already has prefix="/organizer" internally
app.include_router(organizer_applications_router)

# Organizer diagram router manages its own prefix internally
app.include_router(organizer_diagram_router, prefix="", tags=["Organizer Diagram"])
