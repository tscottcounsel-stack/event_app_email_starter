# app/routers/requirements.py
from __future__ import annotations
from typing import Any, Dict

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, ConfigDict

from app.store import _EVENTS, _REQUIREMENTS

router = APIRouter(prefix="/events/{event_id}/requirements", tags=["Requirements"])

class RequirementsPayload(BaseModel):
    model_config = ConfigDict(extra="allow")
    # accept any JSON shape; frontend owns schema for now
    data: Dict[str, Any]

def _ensure_event(event_id: int):
    if event_id not in _EVENTS:
        raise HTTPException(status_code=404, detail="Event not found")

@router.get("")
def get_requirements(event_id: int):
    _ensure_event(event_id)
    return _REQUIREMENTS.get(event_id) or {"data": None}

@router.put("")
def save_requirements(event_id: int, body: RequirementsPayload):
    _ensure_event(event_id)
    _REQUIREMENTS[event_id] = {"data": body.data}
    return {"ok": True, "event_id": event_id}
