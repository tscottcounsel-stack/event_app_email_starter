from __future__ import annotations

import os
import time
from typing import Any, Dict, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, ConfigDict

# --- Optional dependencies (recommended) ---
# pip install "python-jose[cryptography]" passlib[bcrypt]
try:
    from jose import jwt  # type: ignore
except Exception:  # pragma: no cover
    jwt = None  # type: ignore

try:
    from passlib.context import CryptContext  # type: ignore
except Exception:  # pragma: no cover
    CryptContext = None  # type: ignore


router = APIRouter()

# In-memory users (dev-only)
_USERS: dict[int, dict] = {}
_USERS_BY_EMAIL: dict[str, int] = {}
_NEXT_ID = 1

# JWT settings
JWT_SECRET = os.getenv("JWT_SECRET", "dev-secret-change-me")
JWT_ALG = os.getenv("JWT_ALG", "HS256")
JWT_ISS = os.getenv("JWT_ISS", "event-app")
JWT_AUD = os.getenv("JWT_AUD", "event-app-clients")
ACCESS_TOKEN_MINUTES = int(os.getenv("ACCESS_TOKEN_MINUTES", "1440"))  # 24h default

# Password hashing (bcrypt if available)
_pwd = CryptContext(schemes=["bcrypt"], deprecated="auto") if CryptContext else None


class RegisterRequest(BaseModel):
    model_config = ConfigDict(extra="allow")
    email: str
    password: str
    role: str | None = None


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
    email: str


def _hash_password(pw: str) -> str:
    # Dev fallback if passlib missing
    if _pwd is None:
        return f"plain::{pw}"
    return _pwd.hash(pw)


def _verify_password(pw: str, hashed: str) -> bool:
    if _pwd is None:
        # Dev fallback if passlib missing
        if not hashed.startswith("plain::"):
            return False
        return hashed == f"plain::{pw}"
    return _pwd.verify(pw, hashed)


def _create_access_token(*, email: str, role: str, is_active: bool = True) -> str:
    if jwt is None:
        raise HTTPException(
            status_code=500,
            detail='Missing dependency for JWT. Install: python-jose[cryptography]'
        )

    now = int(time.time())
    exp = now + ACCESS_TOKEN_MINUTES * 60

    payload = {
        "sub": email,
        "email": email,
        "role": role,
        "is_active": is_active,
        "iat": now,
        "exp": exp,
        "iss": JWT_ISS,
        "aud": JWT_AUD,
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALG)


@router.post("/register", status_code=200)
def register(payload: RegisterRequest) -> Dict[str, Any]:
    global _NEXT_ID

    role = (payload.role or "vendor").strip().lower()
    if role not in ("vendor", "organizer", "admin"):
        raise HTTPException(status_code=400, detail="Invalid role")

    uid = _USERS_BY_EMAIL.get(payload.email)
    if uid is None:
        uid = _NEXT_ID
        _NEXT_ID += 1

        user = {
            "id": uid,
            "email": payload.email,
            "role": role,
            "password_hash": _hash_password(payload.password),
            "is_active": True,
        }
        _USERS[uid] = user
        _USERS_BY_EMAIL[payload.email] = uid

    # return user (no password)
    u = _USERS[uid].copy()
    u.pop("password_hash", None)
    return u


@router.post("/login", response_model=TokenResponse)
def login(payload: RegisterRequest) -> TokenResponse:
    # If user doesn't exist, auto-register (dev behavior)
    uid = _USERS_BY_EMAIL.get(payload.email)
    if uid is None:
        user = register(payload)
        role = str(user["role"])
        token = _create_access_token(email=payload.email, role=role, is_active=True)
        return TokenResponse(access_token=token, role=role, email=payload.email)

    user = _USERS[uid]
    if not user.get("is_active", True):
        raise HTTPException(status_code=403, detail="Account is inactive")

    if not _verify_password(payload.password, user.get("password_hash", "")):
        raise HTTPException(status_code=401, detail="Invalid login credentials")

    role = str(user.get("role", "vendor"))
    token = _create_access_token(email=payload.email, role=role, is_active=True)
    return TokenResponse(access_token=token, role=role, email=payload.email)


class RefreshRequest(BaseModel):
    access_token: str


@router.post("/refresh", response_model=TokenResponse)
def refresh(payload: RefreshRequest) -> TokenResponse:
    if jwt is None:
        raise HTTPException(
            status_code=500,
            detail='Missing dependency for JWT. Install: python-jose[cryptography]'
        )

    try:
        decoded = jwt.decode(
            payload.access_token,
            JWT_SECRET,
            algorithms=[JWT_ALG],
            audience=JWT_AUD,
            issuer=JWT_ISS,
        )
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid token")

    email = str(decoded.get("email") or decoded.get("sub") or "")
    role = str(decoded.get("role") or "vendor")
    if not email:
        raise HTTPException(status_code=401, detail="Invalid token payload")

    # Optional: ensure user still exists
    uid = _USERS_BY_EMAIL.get(email)
    if uid is None:
        raise HTTPException(status_code=401, detail="User not found")

    token = _create_access_token(email=email, role=role, is_active=True)
    return TokenResponse(access_token=token, role=role, email=email)
