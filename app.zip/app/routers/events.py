# app/routers/events.py
from __future__ import annotations

from typing import Optional, List
from datetime import datetime

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field, ConfigDict

from app.store import _EVENTS, next_event_id, save_store

router = APIRouter(tags=["Events"])


# -------------------------------------------------------------------
# Models
# -------------------------------------------------------------------

class EventCreate(BaseModel):
    """
    Step 1: General Event Details
    """
    model_config = ConfigDict(extra="ignore")

    # Core
    title: str = Field(min_length=1)
    description: Optional[str] = None

    # Dates
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None

    # Location / Venue
    venue_name: Optional[str] = None
    street_address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    zip_code: Optional[str] = None
    location: Optional[str] = None  # backward compatibility
    google_maps_url: Optional[str] = None

    # Metadata
    category: Optional[str] = None
    expected_attendees: Optional[int] = Field(default=None, ge=0)
    setup_time: Optional[str] = None
    additional_notes: Optional[str] = None

    # Media / Links
    image_urls: List[str] = []
    video_urls: List[str] = []
    ticket_urls: List[str] = []


class EventOut(BaseModel):
    id: int
    title: str
    description: Optional[str] = None

    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None

    venue_name: Optional[str] = None
    street_address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    zip_code: Optional[str] = None
    location: Optional[str] = None
    google_maps_url: Optional[str] = None

    category: Optional[str] = None
    expected_attendees: Optional[int] = None
    setup_time: Optional[str] = None
    additional_notes: Optional[str] = None

    image_urls: List[str] = []
    video_urls: List[str] = []
    ticket_urls: List[str] = []

    # Flow state
    archived: bool = False
    layout_published: bool = False

    # Public visibility (what vendors see)
    published: bool = False


class DiagramPayload(BaseModel):
    diagram: dict
    version: Optional[int] = None


class RequirementsPayload(BaseModel):
    requirements: dict
    version: Optional[int] = None


# -------------------------------------------------------------------
# Helpers
# -------------------------------------------------------------------

def _get_event_or_404(event_id: int) -> dict:
    event = _EVENTS.get(event_id)
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    return event


def _ensure_defaults(event: dict) -> dict:
    """
    Backward compatible: if older events exist in memory without new keys.
    """
    if "archived" not in event:
        event["archived"] = False
    if "layout_published" not in event:
        event["layout_published"] = False
    if "published" not in event:
        event["published"] = False
    return event


def _patch_flags(event: dict, body: dict) -> dict:
    """
    Only allow safe boolean flags to be patched.
    """
    allowed = {"archived", "layout_published", "published"}
    for key, value in body.items():
        if key in allowed:
            event[key] = bool(value)
    return event


# -------------------------------------------------------------------
# Routes (Canonical Organizer/Internal) - /events
# -------------------------------------------------------------------

@router.get("/events", response_model=list[EventOut])
def list_events():
    """
    Organizer Events list (shows everything)
    """
    return [_ensure_defaults(e) for e in list(_EVENTS.values())]


@router.post("/events", response_model=EventOut)
def create_event(body: EventCreate):
    """
    Step 1: Create Event (defaults to Draft / unpublished)
    """
    event_id = next_event_id()

    event = {
        "id": event_id,
        "title": body.title,
        "description": body.description,

        "start_date": body.start_date,
        "end_date": body.end_date,

        "venue_name": body.venue_name,
        "street_address": body.street_address,
        "city": body.city,
        "state": body.state,
        "zip_code": body.zip_code,
        "location": body.location,
        "google_maps_url": body.google_maps_url,

        "category": body.category,
        "expected_attendees": body.expected_attendees,
        "setup_time": body.setup_time,
        "additional_notes": body.additional_notes,

        "image_urls": body.image_urls or [],
        "video_urls": body.video_urls or [],
        "ticket_urls": body.ticket_urls or [],

        # flow flags
        "archived": False,
        "layout_published": False,

        # vendors only see published events
        "published": False,
    }

    _EVENTS[event_id] = event
    save_store()
    return event


@router.get("/events/{event_id}", response_model=EventOut)
def get_event(event_id: int):
    """
    Fetch single event
    """
    return _ensure_defaults(_get_event_or_404(event_id))


@router.put("/events/{event_id}", response_model=EventOut)
def update_event(event_id: int, body: EventCreate):
    """
    Update general details (re-save Step 1). Does NOT auto-publish.
    """
    existing = _ensure_defaults(_get_event_or_404(event_id))

    updated = {
        **existing,
        "title": body.title,
        "description": body.description,

        "start_date": body.start_date,
        "end_date": body.end_date,

        "venue_name": body.venue_name,
        "street_address": body.street_address,
        "city": body.city,
        "state": body.state,
        "zip_code": body.zip_code,
        "location": body.location,
        "google_maps_url": body.google_maps_url,

        "category": body.category,
        "expected_attendees": body.expected_attendees,
        "setup_time": body.setup_time,
        "additional_notes": body.additional_notes,

        "image_urls": body.image_urls or [],
        "video_urls": body.video_urls or [],
        "ticket_urls": body.ticket_urls or [],
    }

    _EVENTS[event_id] = updated
    save_store()
    return updated


@router.patch("/events/{event_id}", response_model=EventOut)
def patch_event(event_id: int, body: dict):
    """
    Lightweight updates (flags only):
    - archived
    - layout_published
    - published
    """
    event = _ensure_defaults(_get_event_or_404(event_id))
    event = _patch_flags(event, body)
    _EVENTS[event_id] = event
    save_store()
    return event


@router.post("/events/{event_id}/publish", response_model=EventOut)
def publish_event_canonical(event_id: int):
    """
    Canonical publish: makes event visible in vendor lists.
    """
    event = _ensure_defaults(_get_event_or_404(event_id))
    if event.get("archived"):
        raise HTTPException(status_code=400, detail="Cannot publish an archived event.")
    event["published"] = True
    event["layout_published"] = True  # map layout is now public
    _EVENTS[event_id] = event
    save_store()
    return event


@router.post("/events/{event_id}/unpublish", response_model=EventOut)
def unpublish_event_canonical(event_id: int):
    event = _ensure_defaults(_get_event_or_404(event_id))
    event["published"] = False
    _EVENTS[event_id] = event
    save_store()
    return event


@router.delete("/events/{event_id}")
def delete_event(event_id: int):
    """
    Hard delete event (organizer only)
    """
    _get_event_or_404(event_id)
    del _EVENTS[event_id]
    save_store()
    return {"ok": True}


# -------------------------------------------------------------------
# Diagram + Requirements (Organizer + Public/Vendor)
# Stored directly on the event dict.
# -------------------------------------------------------------------

@router.get("/organizer/events/{event_id}/diagram", tags=["Organizer Diagram"])
def organizer_get_event_diagram(event_id: int):
    event = _ensure_defaults(_get_event_or_404(event_id))
    return {
        "diagram": event.get("diagram", None),
        "version": event.get("diagram_version", None),
    }


@router.put("/organizer/events/{event_id}/diagram", tags=["Organizer Diagram"])
def organizer_save_event_diagram(event_id: int, body: DiagramPayload):
    event = _ensure_defaults(_get_event_or_404(event_id))
    event["diagram"] = body.diagram
    event["diagram_version"] = body.version
    _EVENTS[event_id] = event
    save_store()
    # Return shape that frontend can use directly
    return {
        "diagram": event.get("diagram"),
        "version": event.get("diagram_version"),
    }


@router.post("/organizer/events/{event_id}/diagram", tags=["Organizer Diagram"])
def organizer_save_event_diagram_post(event_id: int, body: DiagramPayload):
    # Frontend tries PUT then POST; support both.
    return organizer_save_event_diagram(event_id, body)


@router.get("/events/{event_id}/diagram", tags=["Public"])
def public_get_event_diagram(event_id: int):
    """
    Public/vendor read-only diagram.
    """
    event = _ensure_defaults(_get_event_or_404(event_id))
    return {
        "diagram": event.get("diagram", None),
        "version": event.get("diagram_version", None),
    }


@router.get("/organizer/events/{event_id}/requirements", tags=["Requirements"])
def organizer_get_event_requirements(event_id: int):
    event = _ensure_defaults(_get_event_or_404(event_id))
    return {
        "requirements": event.get("requirements", None),
        "version": event.get("requirements_version", None),
    }


@router.put("/organizer/events/{event_id}/requirements", tags=["Requirements"])
def organizer_save_event_requirements(event_id: int, body: RequirementsPayload):
    event = _ensure_defaults(_get_event_or_404(event_id))
    event["requirements"] = body.requirements
    event["requirements_version"] = body.version
    _EVENTS[event_id] = event
    save_store()
    return {
        "requirements": event.get("requirements"),
        "version": event.get("requirements_version"),
    }


@router.post("/organizer/events/{event_id}/requirements", tags=["Requirements"])
def organizer_save_event_requirements_post(event_id: int, body: RequirementsPayload):
    # Frontend tries PUT then POST; support both.
    return organizer_save_event_requirements(event_id, body)


@router.get("/events/{event_id}/requirements", tags=["Public"])
def public_get_event_requirements(event_id: int):
    """
    Public/vendor read-only requirements.
    """
    event = _ensure_defaults(_get_event_or_404(event_id))
    return {
        "requirements": event.get("requirements", None),
        "version": event.get("requirements_version", None),
    }


# -------------------------------------------------------------------
# Organizer alias routes (match frontend calls)
# These forward to the canonical /events routes.
# -------------------------------------------------------------------

@router.get("/organizer/events", response_model=list[EventOut], tags=["Organizer"])
def organizer_list_events():
    return list_events()


@router.get("/organizer/events/{event_id}", response_model=EventOut, tags=["Organizer"])
def organizer_get_event(event_id: int):
    return get_event(event_id)


@router.patch("/organizer/events/{event_id}", response_model=EventOut, tags=["Organizer"])
def organizer_patch_event(event_id: int, body: dict):
    return patch_event(event_id, body)


@router.post("/organizer/events/{event_id}/publish", response_model=EventOut, tags=["Organizer"])
def organizer_publish_event(event_id: int):
    return publish_event_canonical(event_id)


@router.post("/organizer/events/{event_id}/unpublish", response_model=EventOut, tags=["Organizer"])
def organizer_unpublish_event(event_id: int):
    return unpublish_event_canonical(event_id)


# -------------------------------------------------------------------
# Vendor-facing
# -------------------------------------------------------------------

@router.get("/vendor/events", response_model=list[EventOut], tags=["Vendor"])
def list_vendor_events():
    """
    Vendor "Available Events" list:
    - only published
    - not archived
    """
    out: list[dict] = []
    for e in _EVENTS.values():
        e = _ensure_defaults(e)
        if e.get("archived"):
            continue
        if not e.get("published"):
            continue
        out.append(e)
    return out


@router.get("/vendor/events/{event_id}", response_model=EventOut, tags=["Vendor"])
def get_vendor_event(event_id: int):
    """
    Vendor can only fetch published, non-archived events.
    """
    e = _ensure_defaults(_get_event_or_404(event_id))
    if e.get("archived") or not e.get("published"):
        raise HTTPException(status_code=404, detail="Event not found")
    return e
