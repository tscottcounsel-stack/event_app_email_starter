# app/routers/organizer_applications.py

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError

from app.db import get_db
from app.models.application import Application

router = APIRouter(prefix="/organizer", tags=["Organizer Applications"])


@router.get("/events/{event_id}/applications")
def get_event_applications(event_id: int, db: Session = Depends(get_db)):
    try:
        apps = (
            db.query(Application)
            .filter(Application.event_id == event_id)
            .order_by(Application.id.desc())
            .all()
        )

        return {
            "applications": [
                {
                    "id": a.id,
                    "event_id": a.event_id,
                    "status": a.status,
                    "vendor_name": a.vendor_name,
                }
                for a in apps
            ]
        }

    except SQLAlchemyError as e:
        raise HTTPException(status_code=500, detail=f"DB error: {str(e)}")


@router.post("/applications/{application_id}/approve")
def approve_application(application_id: int, db: Session = Depends(get_db)):
    try:
        app = db.query(Application).filter(Application.id == application_id).first()
        if not app:
            raise HTTPException(status_code=404, detail="Application not found")

        app.status = "approved"
        db.commit()
        return {"ok": True}

    except SQLAlchemyError as e:
        raise HTTPException(status_code=500, detail=f"DB error: {str(e)}")


@router.post("/applications/{application_id}/reject")
def reject_application(application_id: int, db: Session = Depends(get_db)):
    try:
        app = db.query(Application).filter(Application.id == application_id).first()
        if not app:
            raise HTTPException(status_code=404, detail="Application not found")

        app.status = "rejected"
        db.commit()
        return {"ok": True}

    except SQLAlchemyError as e:
        raise HTTPException(status_code=500, detail=f"DB error: {str(e)}")
