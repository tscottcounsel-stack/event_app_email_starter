from typing import Optional, Any, Dict

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy.orm import Session

from app import models
from app.db import get_db
from app.routers.auth import get_current_vendor

router = APIRouter(prefix="/applications", tags=["applications"])


# -----------------------------
# Schemas
# -----------------------------
class ApplicationCreate(BaseModel):
    model_config = ConfigDict(extra="allow")

    # If frontend sends it, we'll accept it, but we also support path-based apply.
    event_id: Optional[int] = None

    # If your app uses slot/booth selection, keep this.
    slot_id: Optional[int] = None

    price_cents: Optional[int] = Field(default=None, ge=0)
    notes: Optional[str] = None


class ApplicationPatch(BaseModel):
    model_config = ConfigDict(extra="allow")

    status: Optional[str] = None
    notes: Optional[str] = None
    price_cents: Optional[int] = Field(default=None, ge=0)


# -----------------------------
# Helpers
# -----------------------------
def _set_vendor_name_if_supported(app_obj: Any, current_user: Any) -> None:
    """
    Some DBs have vendor_name column (you added it).
    Some older models might not. This keeps it safe.
    """
    if hasattr(app_obj, "vendor_name"):
        # Best guess: use company_name if present, else fallback to email/name
        vendor_name = (
            getattr(current_user, "company_name", None)
            or getattr(current_user, "business_name", None)
            or getattr(current_user, "name", None)
            or getattr(current_user, "email", None)
            or "Vendor"
        )
        app_obj.vendor_name = vendor_name


def _ensure_event_exists(db: Session, event_id: int) -> None:
    # Primary: DB-backed events
    event = db.query(models.Event).filter(models.Event.id == event_id).first()
    if event:
        return

    # Fallback: in-memory events store (your current /events router)
    try:
        from app.store import _EVENTS
        if event_id in _EVENTS:
            return
    except Exception:
        pass

    raise HTTPException(status_code=404, detail="Event not found")

# -----------------------------
# Routes
# -----------------------------
@router.get("/diag/ping")
def applications_diag_ping():
    return {"ping": "pong"}


@router.get("")
def list_applications(
    db: Session = Depends(get_db),
    event_id: Optional[int] = Query(None),
    vendor_id: Optional[int] = Query(None),
):
    """
    REAL DB LIST (not in-memory).
    Useful for debugging and admin tools.
    """
    q = db.query(models.Application)

    if event_id is not None:
        q = q.filter(models.Application.event_id == event_id)

    if vendor_id is not None:
        q = q.filter(models.Application.vendor_id == vendor_id)

    return q.order_by(models.Application.id.desc()).all()


@router.post("", status_code=status.HTTP_201_CREATED)
def create_application(
    payload: ApplicationCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_vendor),
):
    """
    Body-based create (requires payload.event_id). Keep this for compatibility.
    """
    if payload.event_id is None:
        raise HTTPException(
            status_code=422,
            detail="Missing event_id. Use POST /applications/events/{event_id}/apply or include event_id in body.",
        )

    _ensure_event_exists(db, payload.event_id)

    app_obj = models.Application(
        vendor_id=current_user.id,
        event_id=payload.event_id,
        slot_id=payload.slot_id,
        price_cents=payload.price_cents,
        notes=payload.notes,
    )
    _set_vendor_name_if_supported(app_obj, current_user)

    db.add(app_obj)
    db.commit()
    db.refresh(app_obj)
    return app_obj


@router.post("/events/{event_id}/apply", status_code=status.HTTP_201_CREATED)
def apply_to_event(
    event_id: int,
    payload: ApplicationCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_vendor),
):
    """
    ✅ Bulletproof apply endpoint:
    event_id comes from the PATH so it can’t be forgotten by the frontend.
    """
    _ensure_event_exists(db, event_id)

    app_obj = models.Application(
        vendor_id=current_user.id,
        event_id=event_id,
        slot_id=payload.slot_id,
        price_cents=payload.price_cents,
        notes=payload.notes,
    )
    _set_vendor_name_if_supported(app_obj, current_user)

    db.add(app_obj)
    db.commit()
    db.refresh(app_obj)
    return app_obj


@router.patch("/{application_id}")
def patch_application(
    application_id: int,
    payload: ApplicationPatch,
    db: Session = Depends(get_db),
):
    """
    Minimal patch for status/notes/price.
    (If you want organizer auth here later, we can add it.)
    """
    app_obj = db.query(models.Application).filter(models.Application.id == application_id).first()
    if not app_obj:
        raise HTTPException(status_code=404, detail="Application not found")

    if payload.status is not None:
        app_obj.status = payload.status
    if payload.notes is not None:
        app_obj.notes = payload.notes
    if payload.price_cents is not None:
        app_obj.price_cents = payload.price_cents

    db.commit()
    db.refresh(app_obj)
    return app_obj
@router.get("/me")
def list_my_applications(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_vendor),
):
    return (
        db.query(models.Application)
        .filter(models.Application.vendor_id == current_user.id)
        .order_by(models.Application.id.desc())
        .all()
    )

