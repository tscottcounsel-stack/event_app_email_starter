# app/store.py
from __future__ import annotations

from typing import Dict, Any
from pathlib import Path
import json
import threading

# -------------------------------------------------------------------
# Persistence (dev-friendly)
# -------------------------------------------------------------------

_DATA_PATH = Path(__file__).resolve().parent / "_data_store.json"
_LOCK = threading.Lock()


def _int_keyed(d: dict) -> Dict[int, Any]:
    """
    JSON forces keys to strings; convert to int keys for our in-memory dicts.
    """
    out: Dict[int, Any] = {}
    for k, v in (d or {}).items():
        try:
            out[int(k)] = v
        except Exception:
            # If some key isn't numeric, keep it as-is by skipping conversion.
            # (We don't expect that, but this keeps the loader resilient.)
            continue
    return out


def _str_keyed(d: Dict[int, Any]) -> dict:
    """
    Convert int-keyed dict to string-keyed for JSON.
    """
    return {str(k): v for k, v in (d or {}).items()}


def load_store() -> None:
    global _EVENTS, _REQUIREMENTS, _LAYOUT_META, _BOOTHS, _TEMPLATES
    global _NEXT_EVENT_ID, _NEXT_BOOTH_ID, _NEXT_TEMPLATE_ID

    if not _DATA_PATH.exists():
        return

    try:
        raw = json.loads(_DATA_PATH.read_text(encoding="utf-8"))
    except Exception:
        # If the file is corrupted, don't crash the app—just start fresh.
        return

    _EVENTS = _int_keyed(raw.get("events", {}))
    _REQUIREMENTS = _int_keyed(raw.get("requirements", {}))
    _LAYOUT_META = _int_keyed(raw.get("layout_meta", {}))
    _BOOTHS = _int_keyed(raw.get("booths", {}))
    _TEMPLATES = _int_keyed(raw.get("templates", {}))

    nxt = raw.get("next", {}) or {}
    _NEXT_EVENT_ID = int(nxt.get("event_id", 1) or 1)
    _NEXT_BOOTH_ID = int(nxt.get("booth_id", 1) or 1)
    _NEXT_TEMPLATE_ID = int(nxt.get("template_id", 1) or 1)


def save_store() -> None:
    """
    Persist current in-memory state to disk.
    Call after mutations (create/update/delete).
    """
    payload = {
        "events": _str_keyed(_EVENTS),
        "requirements": _str_keyed(_REQUIREMENTS),
        "layout_meta": _str_keyed(_LAYOUT_META),
        "booths": _str_keyed(_BOOTHS),
        "templates": _str_keyed(_TEMPLATES),
        "next": {
            "event_id": _NEXT_EVENT_ID,
            "booth_id": _NEXT_BOOTH_ID,
            "template_id": _NEXT_TEMPLATE_ID,
        },
    }

    with _LOCK:
        _DATA_PATH.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")


# -------------------------------------------------------------------
# In-memory storage (replace with DB later)
# -------------------------------------------------------------------

_EVENTS: Dict[int, Dict[str, Any]] = {}
_REQUIREMENTS: Dict[int, Dict[str, Any]] = {}         # event_id -> requirements json
_LAYOUT_META: Dict[int, Dict[str, Any]] = {}          # event_id -> layout metadata (blocked cells, floors later)
_BOOTHS: Dict[int, Dict[str, Any]] = {}               # booth_id -> booth dict
_TEMPLATES: Dict[int, Dict[str, Any]] = {}            # template_id -> template dict

_NEXT_EVENT_ID = 1
_NEXT_BOOTH_ID = 1
_NEXT_TEMPLATE_ID = 1

# Load persisted state (if present)
load_store()


def next_event_id() -> int:
    global _NEXT_EVENT_ID
    val = _NEXT_EVENT_ID
    _NEXT_EVENT_ID += 1
    save_store()
    return val


def next_booth_id() -> int:
    global _NEXT_BOOTH_ID
    val = _NEXT_BOOTH_ID
    _NEXT_BOOTH_ID += 1
    save_store()
    return val


def next_template_id() -> int:
    global _NEXT_TEMPLATE_ID
    val = _NEXT_TEMPLATE_ID
    _NEXT_TEMPLATE_ID += 1
    save_store()
    return val
