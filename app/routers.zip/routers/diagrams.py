# app/routers/diagrams.py
from __future__ import annotations

from typing import Any, Dict
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException, Body

from app.store import _EVENTS

router = APIRouter(tags=["Diagrams"])

# Stores EXACTLY what the frontend expects: { "diagram": ..., "version": ... }
_EVENT_DIAGRAMS: Dict[int, Dict[str, Any]] = {}


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def get_event_or_404(event_id: int) -> Dict[str, Any]:
    ev = _EVENTS.get(event_id)
    if not ev:
        raise HTTPException(status_code=404, detail="Event not found")
    return ev


def ensure_slot(event_id: int) -> Dict[str, Any]:
    if event_id not in _EVENT_DIAGRAMS or not isinstance(_EVENT_DIAGRAMS.get(event_id), dict):
        _EVENT_DIAGRAMS[event_id] = {"diagram": {"elements": [], "meta": {}}, "version": 0}

    slot = _EVENT_DIAGRAMS[event_id]
    if slot.get("diagram") is None:
        slot["diagram"] = {"elements": [], "meta": {}}
    if slot.get("version") is None:
        slot["version"] = 0

    return slot


@router.get("/organizer/events/{event_id}/diagram")
def get_event_diagram(event_id: int):
    """
    Must return: { diagram: any, version: number }
    """
    get_event_or_404(event_id)
    slot = ensure_slot(event_id)
    return {"diagram": slot["diagram"], "version": int(slot.get("version", 0) or 0)}


@router.put("/organizer/events/{event_id}/diagram")
def save_event_diagram(event_id: int, payload: Dict[str, Any] = Body(...)):
    """
    Expects payload: { diagram: any, version: number|null }
    Returns: { diagram: any, version: number }
    """
    ev = get_event_or_404(event_id)

    diagram = payload.get("diagram", {"elements": [], "meta": {}})
    version = payload.get("version", 0)

    try:
        version = int(version or 0)
    except Exception:
        version = 0

    _EVENT_DIAGRAMS[event_id] = {"diagram": diagram, "version": version}

    # Mark layout progress so dashboard status works
    ev["layout_published"] = True
    ev["updated_at"] = utc_now_iso()

    return {"diagram": diagram, "version": version}
