# app/routers/events.py
from __future__ import annotations

from typing import Optional, List, Dict, Any
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException, Body
from pydantic import BaseModel, Field, ConfigDict

# Import persistent in-memory store from app.store
from app.store import (
    _EVENTS,
    _REQUIREMENTS,
    _LAYOUT_META,  # we'll use this for diagram persistence
    next_event_id,
    save_store,
)

router = APIRouter(tags=["Events"])

# -------------------------------------------------------------------
# Models
# -------------------------------------------------------------------


class EventCreate(BaseModel):
    model_config = ConfigDict(extra="ignore")

    title: str = Field(min_length=1)
    description: Optional[str] = None

    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None

    venue_name: Optional[str] = None
    street_address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    zip_code: Optional[str] = None

    category: Optional[str] = None


class Event(EventCreate):
    id: int
    created_at: str
    updated_at: str

    published: bool = False
    archived: bool = False

    requirements_published: bool = False
    layout_published: bool = False


# -------------------------------------------------------------------
# Helpers
# -------------------------------------------------------------------


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def normalize_event(ev: Dict[str, Any]) -> Dict[str, Any]:
    """
    Makes older in-memory records safe for response_model validation.
    """
    out = dict(ev)

    # id must be int
    try:
        out["id"] = int(out.get("id"))
    except Exception:
        out["id"] = out.get("id")

    # required timestamps
    out.setdefault("created_at", utc_now_iso())
    out.setdefault("updated_at", utc_now_iso())

    # lifecycle flags
    out["published"] = bool(out.get("published", False))
    out["archived"] = bool(out.get("archived", False))

    # progress flags
    out["requirements_published"] = bool(out.get("requirements_published", False))
    out["layout_published"] = bool(out.get("layout_published", False))

    return out


def get_event_or_404(event_id: int) -> Dict[str, Any]:
    ev = _EVENTS.get(event_id)
    if not ev:
        raise HTTPException(status_code=404, detail="Event not found")
    return ev


# ---------------- Diagram (layout) helpers ----------------
# We'll persist diagrams to _LAYOUT_META (store provides this variable).
# Shape: _LAYOUT_META[event_id] = {"diagram": {...}, "version": int}
def ensure_diagram_slot(event_id: int) -> Dict[str, Any]:
    """
    Ensures we always have a valid response shape for the frontend:
    { diagram: {elements:[], meta:{}}, version: 0 }
    Persisted in _LAYOUT_META so layouts survive server restarts.
    """
    slot = _LAYOUT_META.get(event_id)
    if not isinstance(slot, dict):
        _LAYOUT_META[event_id] = {"diagram": {"elements": [], "meta": {}}, "version": 0}
        save_store()
        slot = _LAYOUT_META[event_id]

    # normalize missing keys
    slot.setdefault("diagram", {"elements": [], "meta": {}})
    slot.setdefault("version", 0)
    return slot


# ---------------- Requirements helpers ----------------
# Persisted in _REQUIREMENTS (store provided)
def ensure_requirements_slot(event_id: int) -> Dict[str, Any]:
    """
    Ensures a stable requirements response shape:
    { version: 2, requirements: { compliance_items: [], ... } }
    """
    slot = _REQUIREMENTS.get(event_id)
    if not isinstance(slot, dict):
        _REQUIREMENTS[event_id] = {
            "version": 2,
            "requirements": {
                "event_id": int(event_id),
                "booth_categories": [],
                "custom_restrictions": [],
                "compliance_items": [],
                "document_requirements": [],
                "payment_settings": {
                    "require_deposit": True,
                    "deposit_percent": 50,
                    "late_fee": 0,
                    "refund_policy": "No Refunds",
                    "payment_notes": "",
                },
                "updated_at": utc_now_iso(),
            },
        }
        save_store()
        slot = _REQUIREMENTS[event_id]

    slot.setdefault("version", 2)
    slot.setdefault("requirements", {})

    req = slot["requirements"]
    if not isinstance(req, dict):
        req = {}
        slot["requirements"] = req

    req.setdefault("event_id", int(event_id))
    req.setdefault("booth_categories", [])
    req.setdefault("custom_restrictions", [])
    req.setdefault("compliance_items", [])
    req.setdefault("document_requirements", [])
    req.setdefault(
        "payment_settings",
        {
            "require_deposit": True,
            "deposit_percent": 50,
            "late_fee": 0,
            "refund_policy": "No Refunds",
            "payment_notes": "",
        },
    )
    req["updated_at"] = utc_now_iso()

    return slot


# -------------------------------------------------------------------
# Routes
# -------------------------------------------------------------------


@router.get("/organizer/events", response_model=List[Event])
def list_organizer_events():
    return [normalize_event(e) for e in _EVENTS.values()]


# Optional compatibility alias (prevents old frontend 404s)
@router.get("/events", response_model=List[Event])
def list_events_compat():
    return [normalize_event(e) for e in _EVENTS.values()]


@router.post("/organizer/events", response_model=Event)
def create_event(payload: EventCreate):
    event_id = next_event_id()
    now = utc_now_iso()

    event = {
        "id": event_id,
        **payload.model_dump(),
        "created_at": now,
        "updated_at": now,
        "published": False,
        "archived": False,
        "requirements_published": False,
        "layout_published": False,
    }

    _EVENTS[event_id] = event

    # Create empty slots so GET works immediately (persist)
    ensure_diagram_slot(event_id)
    ensure_requirements_slot(event_id)
    save_store()

    return normalize_event(event)


@router.get("/organizer/events/{event_id}", response_model=Event)
def get_event(event_id: int):
    ev = get_event_or_404(event_id)
    return normalize_event(ev)


@router.put("/organizer/events/{event_id}", response_model=Event)
def update_event(event_id: int, payload: EventCreate):
    ev = get_event_or_404(event_id)

    for k, v in payload.model_dump().items():
        ev[k] = v

    ev["updated_at"] = utc_now_iso()
    save_store()
    return normalize_event(ev)


@router.post("/organizer/events/{event_id}/publish", response_model=Event)
def publish_event(event_id: int):
    ev = get_event_or_404(event_id)

    if ev.get("archived"):
        raise HTTPException(status_code=400, detail="Cannot publish archived event")

    ev["published"] = True
    ev["updated_at"] = utc_now_iso()
    save_store()
    return normalize_event(ev)


@router.post("/organizer/events/{event_id}/unpublish", response_model=Event)
def unpublish_event(event_id: int):
    ev = get_event_or_404(event_id)

    ev["published"] = False
    ev["updated_at"] = utc_now_iso()
    save_store()
    return normalize_event(ev)


@router.post("/organizer/events/{event_id}/archive", response_model=Event)
def archive_event(event_id: int):
    ev = get_event_or_404(event_id)

    ev["archived"] = True
    ev["updated_at"] = utc_now_iso()
    save_store()
    return normalize_event(ev)


# -------------------------------------------------------------------
# Requirements endpoints
# IMPORTANT: return the SAME SHAPE organizer saves:
#   { "version": int, "requirements": { ... snake_case ... } }
# -------------------------------------------------------------------


@router.get("/organizer/events/{event_id}/requirements")
def get_event_requirements_organizer(event_id: int):
    get_event_or_404(event_id)
    slot = ensure_requirements_slot(event_id)
    return slot


@router.put("/organizer/events/{event_id}/requirements")
def save_event_requirements_organizer(event_id: int, payload: Dict[str, Any] = Body(...)):
    get_event_or_404(event_id)

    version = payload.get("version", 2)
    try:
        version = int(version or 2)
    except Exception:
        version = 2

    requirements = payload.get("requirements", {}) or {}
    if not isinstance(requirements, dict):
        requirements = {}

    requirements["event_id"] = int(event_id)
    requirements["updated_at"] = utc_now_iso()

    _REQUIREMENTS[event_id] = {"version": version, "requirements": requirements}

    # mark progress flag so dashboard can show readiness
    ev = _EVENTS.get(event_id)
    if ev is not None:
        ev["requirements_published"] = True
        ev["updated_at"] = utc_now_iso()

    save_store()
    return _REQUIREMENTS[event_id]


@router.post("/organizer/events/{event_id}/requirements")
def save_event_requirements_organizer_post(event_id: int, payload: Dict[str, Any] = Body(...)):
    # frontend may try POST if PUT fails
    return save_event_requirements_organizer(event_id, payload)


@router.get("/events/{event_id}/requirements")
def get_event_requirements_public(event_id: int):
    """
    Vendor/public read endpoint.
    Return SAME SHAPE as organizer saves so vendor can render compliance checkboxes.
    """
    get_event_or_404(event_id)
    slot = ensure_requirements_slot(event_id)
    return slot


# -------------------------------------------------------------------
# Diagram endpoints (Map Editor / Vendor preview)
# Must return: { diagram: any, version: number }
# We'll persist to _LAYOUT_META so "Save Layout" actually persists.
# -------------------------------------------------------------------


@router.get("/organizer/events/{event_id}/diagram")
def get_event_diagram(event_id: int):
    """
    Must return: { diagram: any, version: number }
    """
    get_event_or_404(event_id)
    slot = ensure_diagram_slot(event_id)
    return {"diagram": slot["diagram"], "version": int(slot.get("version", 0) or 0)}


@router.put("/organizer/events/{event_id}/diagram")
def save_event_diagram(event_id: int, payload: Dict[str, Any] = Body(...)):
    """
    Expects payload: { diagram: any, version: number|null }
    Returns: { diagram: any, version: number }
    """
    get_event_or_404(event_id)

    diagram = payload.get("diagram", {"elements": [], "meta": {}})
    version = payload.get("version", 0)
    try:
        version = int(version or 0)
    except Exception:
        version = 0

    _LAYOUT_META[event_id] = {"diagram": diagram, "version": version}

    # mark layout progress flag so dashboard can show Ready/Progress correctly
    ev = _EVENTS.get(event_id)
    if ev is not None:
        ev["layout_published"] = True
        ev["updated_at"] = utc_now_iso()

    save_store()
    return {"diagram": diagram, "version": version}
