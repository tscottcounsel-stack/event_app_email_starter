# app/routers/applications.py
from __future__ import annotations

from typing import Any, Dict, List, Optional
from datetime import datetime, timezone

from fastapi import APIRouter, Body, HTTPException, Request
from pydantic import BaseModel, ConfigDict

from app.store import _EVENTS, _APPLICATIONS, next_application_id, save_store

router = APIRouter(tags=["Applications"])


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def get_event_or_404(event_id: int) -> Dict[str, Any]:
    ev = _EVENTS.get(event_id)
    if not ev:
        raise HTTPException(status_code=404, detail="Event not found")
    return ev


def try_extract_identity(req: Request) -> Dict[str, Optional[str]]:
    """
    Best-effort identity extraction.
    If you later add real auth dependencies, swap this out.
    """
    email = req.headers.get("x-user-email")
    user_id = req.headers.get("x-user-id")
    return {"vendor_email": email, "vendor_id": user_id}


class ApplicationCreate(BaseModel):
    """
    Accepts whatever the frontend sends today, without breaking.
    Your current VendorEventApplyPage sends only: { notes }
    We'll also accept boothId/appId/checked/etc when you add them.
    """
    model_config = ConfigDict(extra="allow")

    notes: Optional[str] = None
    boothId: Optional[str] = None
    booth_id: Optional[str] = None
    appId: Optional[str] = None
    app_id: Optional[str] = None

    # optional: compliance confirmations (future)
    checked: Optional[Dict[str, bool]] = None


# -------------------------------------------------------------------
# Vendor: submit application
# -------------------------------------------------------------------

@router.post("/applications/events/{event_id}/apply")
def submit_application(event_id: int, request: Request, payload: ApplicationCreate = Body(...)):
    get_event_or_404(event_id)

    ident = try_extract_identity(request)
    app_id = next_application_id()

    booth_id = payload.booth_id or payload.boothId
    app_ref = payload.app_id or payload.appId

    app = {
        "id": app_id,
        "event_id": int(event_id),
        "booth_id": booth_id,
        "app_ref": app_ref,
        "notes": payload.notes or "",
        "checked": payload.checked or {},
        "status": "submitted",
        "submitted_at": utc_now_iso(),
        "updated_at": utc_now_iso(),
        "vendor_email": ident.get("vendor_email"),
        "vendor_id": ident.get("vendor_id"),
    }

    _APPLICATIONS[app_id] = app

    # Optional progress marker (if you want organizer UI to show activity)
    ev = _EVENTS.get(event_id)
    if ev is not None:
        ev["updated_at"] = utc_now_iso()

    save_store()
    return {"ok": True, "application": app}


# -------------------------------------------------------------------
# Organizer: list applications for an event
# -------------------------------------------------------------------

@router.get("/organizer/events/{event_id}/applications")
def list_event_applications(event_id: int) -> Dict[str, Any]:
    get_event_or_404(event_id)
    apps = [a for a in _APPLICATIONS.values() if int(a.get("event_id", -1)) == int(event_id)]
    # newest first
    apps.sort(key=lambda x: x.get("submitted_at") or "", reverse=True)
    return {"event_id": int(event_id), "applications": apps}


# -------------------------------------------------------------------
# Vendor: list all applications (for /vendor/applications page if needed)
# -------------------------------------------------------------------

@router.get("/vendor/applications")
def list_vendor_applications() -> Dict[str, Any]:
    apps = list(_APPLICATIONS.values())
    apps.sort(key=lambda x: x.get("submitted_at") or "", reverse=True)
    return {"applications": apps}
