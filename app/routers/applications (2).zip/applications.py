# app/routers/applications.py
from __future__ import annotations

from typing import Any, Dict, List, Optional
from datetime import datetime, timezone

from fastapi import APIRouter, Body, HTTPException, Request
from pydantic import BaseModel, ConfigDict

from app.store import _EVENTS, _APPLICATIONS, next_application_id, save_store

router = APIRouter(tags=["Applications"])


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def get_event_or_404(event_id: int) -> Dict[str, Any]:
    ev = _EVENTS.get(int(event_id))
    if not ev:
        raise HTTPException(status_code=404, detail="Event not found")
    return ev


def try_extract_identity(req: Request) -> Dict[str, Optional[str]]:
    email = req.headers.get("x-user-email")
    user_id = req.headers.get("x-user-id")
    return {"vendor_email": email, "vendor_id": user_id}


class ApplicationCreate(BaseModel):
    model_config = ConfigDict(extra="allow")

    notes: Optional[str] = None
    boothId: Optional[str] = None
    booth_id: Optional[str] = None
    appId: Optional[str] = None
    app_id: Optional[str] = None
    checked: Optional[Dict[str, bool]] = None


# -------------------------------------------------------------------
# Vendor: submit application
# -------------------------------------------------------------------

@router.post("/applications/events/{event_id}/apply")
def submit_application(
    event_id: int,
    request: Request,
    payload: ApplicationCreate = Body(...),
):
    get_event_or_404(event_id)

    ident = try_extract_identity(request)
    vendor_id = ident.get("vendor_id")
    vendor_email = ident.get("vendor_email")

    booth_id = payload.booth_id or payload.boothId
    app_ref = payload.app_id or payload.appId

    # Prevent duplicate submission (same vendor + event + booth)
    for existing in _APPLICATIONS.values():
        if (
            int(existing.get("event_id", -1)) == int(event_id)
            and existing.get("booth_id") == booth_id
            and (
                (vendor_id and existing.get("vendor_id") == vendor_id)
                or (vendor_email and existing.get("vendor_email") == vendor_email)
            )
        ):
            raise HTTPException(
                status_code=400,
                detail="Application already submitted for this booth",
            )

    app_id = next_application_id()

    app = {
        "id": app_id,
        "event_id": int(event_id),
        "booth_id": booth_id,
        "app_ref": app_ref,
        "notes": payload.notes or "",
        "checked": payload.checked or {},
        "status": "submitted",
        "submitted_at": utc_now_iso(),
        "updated_at": utc_now_iso(),
        "vendor_email": vendor_email,
        "vendor_id": vendor_id,
    }

    _APPLICATIONS[app_id] = app

    ev = _EVENTS.get(int(event_id))
    if ev is not None:
        ev["updated_at"] = utc_now_iso()

    save_store()

    return {"ok": True, "application": app}


# -------------------------------------------------------------------
# Organizer: list applications for event
# -------------------------------------------------------------------

@router.get("/organizer/events/{event_id}/applications")
def list_event_applications(event_id: int) -> Dict[str, Any]:
    get_event_or_404(event_id)

    apps = [
        a
        for a in _APPLICATIONS.values()
        if int(a.get("event_id", -1)) == int(event_id)
    ]

    apps.sort(key=lambda x: x.get("submitted_at") or "", reverse=True)

    return {"event_id": int(event_id), "applications": apps}


# -------------------------------------------------------------------
# Vendor: list their applications
# -------------------------------------------------------------------

@router.get("/vendor/applications")
def list_vendor_applications(request: Request) -> Dict[str, Any]:
    ident = try_extract_identity(request)
    vendor_id = ident.get("vendor_id")
    vendor_email = ident.get("vendor_email")

    if not vendor_id and not vendor_email:
        return {"applications": []}

    apps = [
        a
        for a in _APPLICATIONS.values()
        if (
            (vendor_id and a.get("vendor_id") == vendor_id)
            or (vendor_email and a.get("vendor_email") == vendor_email)
        )
    ]

    apps.sort(key=lambda x: x.get("submitted_at") or "", reverse=True)

    return {"applications": apps}

@router.post("/organizer/applications/{application_id}/status")
def update_application_status(
    application_id: int,
    payload: Dict[str, Any] = Body(...),
):
    app = _APPLICATIONS.get(int(application_id))
    if not app:
        raise HTTPException(status_code=404, detail="Application not found")

    status = payload.get("status")
    if status not in ("approved", "rejected"):
        raise HTTPException(status_code=400, detail="Invalid status")

    app["status"] = status
    app["updated_at"] = utc_now_iso()

    save_store()

    return {"ok": True, "application": app}
