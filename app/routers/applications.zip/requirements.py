# app/routers/requirements.py
from __future__ import annotations

from typing import Any, Dict, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, ConfigDict

from app.store import _EVENTS, _REQUIREMENTS

router = APIRouter(tags=["Requirements"])


class RequirementsSavePayload(BaseModel):
    """
    Accepts BOTH:
      A) { "requirements": {...}, "version": 1 }
      B) the organizer RequirementsModel directly (your UI sends this)
    """
    model_config = ConfigDict(extra="allow")

    requirements: Optional[Dict[str, Any]] = None
    version: Optional[Any] = None  # can be int or string in your current UI


def _ensure_event(event_id: int) -> Dict[str, Any]:
    e = _EVENTS.get(event_id)
    if not e:
        raise HTTPException(status_code=404, detail="Event not found")
    return e


def _normalize_save_body(payload: RequirementsSavePayload) -> tuple[Dict[str, Any], int]:
    raw = payload.model_dump()

    # If wrapped { requirements: {...} } use it.
    if isinstance(raw.get("requirements"), dict):
        req = raw["requirements"]
        ver_raw = raw.get("version")
    else:
        # Otherwise the organizer sent the RequirementsModel directly
        req = raw
        ver_raw = raw.get("version")

    # Normalize version to an int if possible, else default to 1
    try:
        ver = int(ver_raw) if ver_raw is not None else 1
    except Exception:
        ver = 1

    return req, ver


# ---------------------------------------------------------
# Organizer endpoints (canonical)
# ---------------------------------------------------------

@router.get("/organizer/events/{event_id}/requirements")
def organizer_get_event_requirements(event_id: int):
    _ensure_event(event_id)
    saved = _REQUIREMENTS.get(event_id)

    if not saved:
        return {"requirements": {}, "version": 0}

    return {"requirements": saved.get("requirements", {}), "version": saved.get("version", 0)}


@router.put("/organizer/events/{event_id}/requirements")
def organizer_put_event_requirements(event_id: int, payload: RequirementsSavePayload):
    _ensure_event(event_id)
    req, ver = _normalize_save_body(payload)

    _REQUIREMENTS[event_id] = {"requirements": req, "version": ver}
    return {"ok": True, "version": ver}


@router.post("/organizer/events/{event_id}/requirements")
def organizer_post_event_requirements(event_id: int, payload: RequirementsSavePayload):
    # behave same as PUT for now
    return organizer_put_event_requirements(event_id, payload)


# ---------------------------------------------------------
# Public/Vendor-facing endpoint
# ---------------------------------------------------------

@router.get("/events/{event_id}/requirements")
def public_get_event_requirements(event_id: int):
    _ensure_event(event_id)
    saved = _REQUIREMENTS.get(event_id)

    if not saved:
        # IMPORTANT: return {} not null so vendor UI can render empty state cleanly
        return {"requirements": {}, "version": 0}

    return {"requirements": saved.get("requirements", {}), "version": saved.get("version", 0)}
