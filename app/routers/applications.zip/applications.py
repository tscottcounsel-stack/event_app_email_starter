# app/routers/applications.py
from typing import Optional, Any, Dict

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy.orm import Session

from app.db import get_db
from app.models.application import Application
from app.routers.auth import get_current_vendor

router = APIRouter(prefix="/applications", tags=["applications"])


class ApplicationCreate(BaseModel):
    model_config = ConfigDict(extra="allow")

    # optional body fields (booth/slot selection later)
    notes: Optional[str] = None
    slot_id: Optional[int] = None
    price_cents: Optional[int] = Field(default=None, ge=0)


class ApplicationPatch(BaseModel):
    model_config = ConfigDict(extra="allow")

    status: Optional[str] = None
    notes: Optional[str] = None


def _vendor_name_from_token(user: Dict[str, Any]) -> str:
    # Your JWT payload includes email/sub; use that as stable vendor identifier for now.
    return str(user.get("email") or user.get("sub") or "vendor")


@router.get("")
def list_applications(
    db: Session = Depends(get_db),
    event_id: Optional[int] = Query(None),
):
    q = db.query(Application)
    if event_id is not None:
        q = q.filter(Application.event_id == event_id)
    return q.order_by(Application.id.desc()).all()


@router.get("/me")
def list_my_applications(
    db: Session = Depends(get_db),
    current_vendor: dict = Depends(get_current_vendor),
):
    vendor_name = _vendor_name_from_token(current_vendor)
    return (
        db.query(Application)
        .filter(Application.vendor_name == vendor_name)
        .order_by(Application.id.desc())
        .all()
    )


@router.post("/events/{event_id}/apply", status_code=status.HTTP_201_CREATED)
def apply_to_event(
    event_id: int,
    payload: ApplicationCreate,
    db: Session = Depends(get_db),
    current_vendor: dict = Depends(get_current_vendor),
):
    vendor_name = _vendor_name_from_token(current_vendor)

    app_obj = Application(
        event_id=event_id,
        status="pending",
        vendor_name=vendor_name,
    )

    # If you later add columns for these, they’ll automatically start persisting.
    if hasattr(app_obj, "notes"):
        setattr(app_obj, "notes", payload.notes)
    if hasattr(app_obj, "slot_id"):
        setattr(app_obj, "slot_id", payload.slot_id)
    if hasattr(app_obj, "price_cents"):
        setattr(app_obj, "price_cents", payload.price_cents)

    db.add(app_obj)
    db.commit()
    db.refresh(app_obj)
    return app_obj


@router.patch("/{application_id}")
def patch_application(
    application_id: int,
    payload: ApplicationPatch,
    db: Session = Depends(get_db),
):
    app_obj = db.query(Application).filter(Application.id == application_id).first()
    if not app_obj:
        raise HTTPException(status_code=404, detail="Application not found")

    if payload.status is not None:
        app_obj.status = payload.status
    if payload.notes is not None and hasattr(app_obj, "notes"):
        setattr(app_obj, "notes", payload.notes)

    db.commit()
    db.refresh(app_obj)
    return app_obj
